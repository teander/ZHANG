# -*- coding: utf-8 -*-
"""
银行流水自动对账工具 v2.2.1

用途：把「财务日记账」和「银行流水」两份 Excel 做逐笔对账，输出一份带匹配结果的新表格。

设计要点
--------
1. 全程本地离线：只读源文件，不联网、不上传、不修改原表。
2. 表头自动定位 + 列名多候选识别；识别不出来就明确报错，不静默乱对。
3. 户名是硬判据：两侧都有对方名称时，名称对不上就不配，宁可列入待查也不硬凑。
4. 每笔只能被用一次：匹配成功后打上 used 标记，避免同一笔钱被重复认领。
5. 分层匹配：金额精确 -> 金额容差 -> 小额差额（手续费/净额到账）
   -> 一笔对多笔 / 多笔对一笔（拆笔到账允许跨 3 天）
   -> 双向唯一且户名对得上的兜底；户名对不上的一律不硬配。
6. 匹配不了的两侧记录会放进「待查手工核对」页左右排列，可手工填组号回传。
7. 结果可复核：每行标出匹配组号、匹配方式、关联笔数、匹配金额、差额、状态与原因。
8. 匹配前先体检（v2.2.1）：拿数据本身核对「收付方向、到账滞后、户名写法」三件事，
   发现整体性错位会自动校正，并在「对账汇总」的【匹配前体检】里留下数字和说明，
   避免因为一个全局性的小问题导致整份账大面积配不上。
9. 体检还会报出「日记账比流水多多少笔」「有多少组同额一收一支（疑似内部划转）」，
   并提示未匹配里有多少是流水侧本来就没有的，避免把正常差异当成程序错。
10. 结果默认保存到日记账所在文件夹，界面上有「打开结果文件夹」按钮。

运行方式：双击「双击运行对账工具.bat」，或 python 银行流水对账工具.py
"""
from __future__ import annotations

import hashlib
import logging
import os
import queue
import re
import sys
import threading
import time
import traceback
import unicodedata
from collections import defaultdict
from dataclasses import dataclass, field, replace
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from difflib import SequenceMatcher

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_PYLIBS = os.path.join(BASE_DIR, 'pylibs')
if os.path.isdir(_PYLIBS) and _PYLIBS not in sys.path:
    sys.path.insert(0, _PYLIBS)

IMPORT_ERROR = None
try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.formatting.rule import FormulaRule
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
except Exception as _exc:  # 依赖缺失时不让程序直接崩，留给 main 统一提示
    IMPORT_ERROR = _exc

VERSION = '2.2.2'
APP_NAME = '银行流水自动对账工具'
MAX_GROUP = 30             # 组匹配最多几笔（含单笔目标，支持 1笔对 N笔 / N笔对 1笔 加总）
LOG_KEEP_DAYS = 30


class UserError(Exception):
    """可以直接展示给使用者看的错误（不含技术细节）。"""


# ---------------------------------------------------------------------------
# 基础工具：文本归一化、金额、日期、名称
# ---------------------------------------------------------------------------

def to_halfwidth(text):
    """全角转半角，兼容中文输入法下录入的符号。"""
    return unicodedata.normalize('NFKC', str(text))


_HDR_NOISE = re.compile(r'[\s\u3000()\[\]{}【】:：*]+')


def clean_header(value):
    """表头比较用的规范形式：去空格/括号/标点并转小写。"""
    if value is None:
        return ''
    s = to_halfwidth(value)
    return _HDR_NOISE.sub('', s).lower()


def _cell_has_value(value):
    if value is None:
        return False
    return str(value).strip() != ''


def _row_has_value(row):
    return any(_cell_has_value(c) for c in row)


def _get(row, index):
    if index is None or index < 0 or index >= len(row):
        return None
    return row[index]


_CORP_SUFFIX = re.compile(
    r'(有限责任公司|股份有限公司|集团有限公司|有限公司|股份公司|集团公司|分公司|公司|经营部|商行|门店|厂)$'
)


def normalize_name(value):
    """对方名称归一化：全角转半角、去空格与括号。"""
    if value is None:
        return ''
    s = to_halfwidth(value)
    s = re.sub(r'\s+', '', s)
    s = re.sub(r'[()\[\]{}【】]', '', s)
    return s


def _strip_corp(name):
    return _CORP_SUFFIX.sub('', name) if name else name


def name_similarity(a, b):
    """0~1 的名称相似度，账号相同视为高度相似。"""
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    if a in b or b in a:
        return 0.95
    acc_a = set(re.findall(r'\d{6,}', a))
    acc_b = set(re.findall(r'\d{6,}', b))
    if acc_a & acc_b:
        return 0.98
    sa, sb = _strip_corp(a), _strip_corp(b)
    if sa and sb and sa == sb:
        return 0.93
    return max(SequenceMatcher(None, a, b).ratio(),
               SequenceMatcher(None, sa, sb).ratio() if sa and sb else 0.0)


_AMT_SUFFIX = re.compile(r'(人民币|CNY|RMB|元|圆|块)$', re.IGNORECASE)


def parse_amount(value):
    """金额 -> 分（int）。无法识别返回 None，空值返回 0。"""
    if value is None:
        return 0
    if isinstance(value, bool):
        return None
    if isinstance(value, (datetime, date)):
        return None
    if isinstance(value, int):
        return value * 100
    if isinstance(value, float):
        if value != value or value in (float('inf'), float('-inf')):
            return None
        return int(round(value * 100))
    if isinstance(value, Decimal):
        return int((value * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))

    s = to_halfwidth(value).strip()
    if not s:
        return 0

    negative = False
    if len(s) > 2 and s.startswith('(') and s.endswith(')'):
        negative = True
        s = s[1:-1]

    s = s.replace(',', '').replace(' ', '').replace('\u3000', '')
    s = s.replace('\u00a5', '').replace('$', '')
    s = _AMT_SUFFIX.sub('', s)
    if s in ('', '-', '--', '/', '\u2014', '\u2013'):
        return 0
    if s.endswith('-'):
        negative = True
        s = s[:-1]
    if s.startswith('-'):
        negative = not negative
        s = s[1:]

    try:
        number = Decimal(s)
    except (InvalidOperation, ValueError):
        return None
    cents = int((number * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))
    return -cents if negative else cents


_DATE_RE = re.compile(r'^(\d{4})[-/.年]?(\d{1,2})[-/.月]?(\d{1,2})')
_YYYYMMDD_RE = re.compile(r'^\d{8}$')


def _from_ymd(year, month, day):
    try:
        return date(int(year), int(month), int(day))
    except ValueError:
        return None


def _excel_serial(value):
    try:
        return (datetime(1899, 12, 30) + timedelta(days=float(value))).date()
    except (OverflowError, ValueError):
        return None


def parse_date(value):
    """日期 -> date；无法识别返回 None。

    支持：datetime / date / Excel 日期序列号 / 8 位 YYYYMMDD（如 20260102，
    银行导出的交易日期常是这种整数或字符串）/ 2024-1-5 / 2024/01/05 /
    2024.1.5 / 2024年1月5日。
    """
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        if 20000 <= value <= 80000:  # Excel 日期序列号
            return _excel_serial(value)
        if 10000101 <= value <= 29991231:  # 8 位 YYYYMMDD 整数
            s = '{0:08.0f}'.format(value) if isinstance(value, float) else str(int(value))
            if _YYYYMMDD_RE.match(s):
                return _from_ymd(s[0:4], s[4:6], s[6:8])
        return None

    s = to_halfwidth(value).strip()
    if not s:
        return None
    if _YYYYMMDD_RE.match(s):  # 字符串形式的 20260102
        return _from_ymd(s[0:4], s[4:6], s[6:8])
    m = _DATE_RE.match(s)
    if not m:
        return None
    return _from_ymd(m.group(1), m.group(2), m.group(3))


def _year_of(value):
    d = parse_date(value)
    return d.year if d else None


# ---------------------------------------------------------------------------
# 表结构识别
# ---------------------------------------------------------------------------

HEADER_HINTS = (
    '日期', '时间', '摘要', '对方', '户名', '单位', '借方', '贷方', '收入', '支出',
    '金额', '余额', '凭证', '用途', '备注', '账号', '方向', '标志', '币种', '流水', '交易',
)

DATE_C = ('交易日期', '记账日期', '入账日期', '发生日期', '日期', '交易时间', '记账时间', '时间', 'date')
NAME_C = ('对方户名', '对方名称', '对方单位', '对方账户名称', '对方账户',
          '户名', '对方', '单位名称', '客户名称', '往来单位', '交易对方')
# 按方向区分的对方名称：金额为负(贷方/支出)用收款人，金额为正(借方/收入)用付款人
RECEIVER_C = ('收款人名称', '收款人', '收款方名称', '收款方', '收款单位', '贷方户名')
PAYER_C = ('付款人名称', '付款人', '付款方名称', '付款方', '付款单位', '借方户名')
SUMMARY_C = ('摘要', '用途', '附言', '备注', '交易类型', '业务类型', '说明')
BALANCE_C = ('余额', '账户余额', '交易后余额')
VOUCHER_C = ('凭证号', '凭证字号', '凭证编号', '记账凭证号', '凭单号', '凭证', 'voucher')
INDEX_C = ('索引号', '索引', '序号', 'index')
AMOUNT_C = ('交易金额', '发生额', '金额', '交易额')
FLAG_C = ('借贷标志', '收付标志', '收支标志', '借贷方向', '收付方向', '交易方向', '方向', '借贷', '收付')

# 日记账：借方=收入，贷方=支出
J_IN = ('借方金额', '借方发生额', '借方', '收入金额', '收入', '存入金额', '存入', '进账金额', '进账')
J_OUT = ('贷方金额', '贷方发生额', '贷方', '支出金额', '支出', '取出', '支取', '出账金额')

# 银行流水：贷方/收入=进账，借方/支出=出账
B_IN = ('收入金额', '收入', '贷方金额', '贷方发生额', '贷方', '存入金额', '存入', '进账金额', '进账', '贷记金额')
B_OUT = ('支出金额', '支出', '借方金额', '借方发生额', '借方', '取出', '支取', '出账金额', '借记金额')


def find_col(headers, candidates, used):
    """按「完全相等 -> 前缀 -> 包含」三级优先找列，返回下标或 -1。"""
    norm = [clean_header(h) for h in headers]
    cands = [clean_header(c) for c in candidates]
    for c in cands:
        for i, h in enumerate(norm):
            if i not in used and h == c:
                return i
    for c in cands:
        for i, h in enumerate(norm):
            if i not in used and h.startswith(c):
                return i
    for c in cands:
        for i, h in enumerate(norm):
            if i not in used and c in h:
                return i
    return -1


def map_columns(headers, src):
    """把表头映射到语义列。src: journal / bank。"""
    used = set()
    mapping = {}

    def pick(cands):
        idx = find_col(headers, cands, used)
        if idx >= 0:
            used.add(idx)
        return idx

    mapping['date'] = pick(DATE_C)
    if src == 'journal':
        mapping['inflow'] = pick(J_IN)
        mapping['outflow'] = pick(J_OUT)
    else:
        mapping['inflow'] = pick(B_IN)
        mapping['outflow'] = pick(B_OUT)
    mapping['name'] = pick(NAME_C)
    mapping['receiver'] = pick(RECEIVER_C)
    mapping['payer'] = pick(PAYER_C)
    mapping['summary'] = pick(SUMMARY_C)
    mapping['balance'] = pick(BALANCE_C)
    mapping['voucher'] = pick(VOUCHER_C)
    mapping['index'] = pick(INDEX_C)

    if mapping['inflow'] < 0 and mapping['outflow'] < 0:
        mapping['amount'] = pick(AMOUNT_C)
        mapping['flag'] = pick(FLAG_C)
        if mapping['receiver'] >= 0 or mapping['payer'] >= 0:
            # 单列“交易金额”，正=借方/收入(付款人)，负=贷方/支出(收款人)
            mapping['mode'] = 'signed'
            mapping['name'] = -1   # 名称由 receiver/payer 按方向决定
        else:
            mapping['mode'] = 'single'
    else:
        mapping['amount'] = -1
        mapping['flag'] = -1
        mapping['receiver'] = -1
        mapping['payer'] = -1
        mapping['mode'] = 'two'
    return mapping


def _trim_rows(rows):
    rows = [list(r) for r in rows]
    while rows and not _row_has_value(rows[-1]):
        rows.pop()
    if not rows:
        return []
    width = max(len(r) for r in rows)
    for r in rows:
        if len(r) < width:
            r.extend([None] * (width - len(r)))
    while width > 0 and all(not _cell_has_value(r[width - 1]) for r in rows):
        width -= 1
    return [r[:width] for r in rows]


def _header_candidates(rows, max_scan=30):
    scored = []
    for i, row in enumerate(rows[:max_scan]):
        score = 0
        for cell in row:
            if not _cell_has_value(cell):
                continue
            text = clean_header(cell)
            if any(hint in text for hint in HEADER_HINTS):
                score += 1
        if score >= 2:
            scored.append((score, i))
    scored.sort(key=lambda x: (-x[0], x[1]))
    return [idx for _score, idx in scored[:8]]


def read_table_raw(path, label):
    """读取工作簿，返回第一个有内容的工作表（原始行 + 表头候选行号）。"""
    if not os.path.isfile(path):
        raise UserError('{0}：文件不存在\n{1}'.format(label, path))
    ext = os.path.splitext(path)[1].lower()
    if ext == '.xls':
        raise UserError('{0}：这是旧版 .xls 文件，本工具读不了。\n请用 Excel 打开后「另存为」.xlsx 再选。'.format(label))
    if ext == '.csv':
        raise UserError('{0}：这是 CSV 文件，请用 Excel 打开后「另存为」.xlsx 再选。'.format(label))
    if ext not in ('.xlsx', '.xlsm'):
        raise UserError('{0}：只支持 .xlsx / .xlsm，当前是 {1}'.format(label, ext or '无扩展名'))

    try:
        wb = load_workbook(path, read_only=True, data_only=True)
    except PermissionError:
        raise UserError('{0}：文件被占用或没有读取权限。\n如果正在 Excel 中打开，请先关闭。'.format(label))
    except Exception as exc:
        raise UserError('{0}：无法打开工作簿（{1}）。\n{2}'.format(label, type(exc).__name__, exc))

    try:
        best_score = -1
        best_rows = None
        best_sheet = ''
        for name in wb.sheetnames[:10]:
            ws = wb[name]
            rows = [tuple(r) for r in ws.iter_rows(values_only=True)]
            if not any(_row_has_value(r) for r in rows):
                continue
            cands = _header_candidates(rows)
            if not cands:
                continue
            # 选表头候选得分最高的 sheet（首个非空可能并非真正的明细表）
            cands_scores = [i for i in cands]
            score = len(cands_scores)
            # 用 header 匹配得分辅助判断：日期+金额列都出现则更可信
            trimmed = _trim_rows(rows)
            if trimmed and cands_scores:
                hdr = trimmed[cands_scores[0]]
                htext = [clean_header(h) for h in hdr]
                if any(any(c in h for c in ('日期', 'date', '交易', '记账')) for h in htext):
                    score += 5
                if any(any(c in h for c in ('金额', '借方', '贷方', '收入', '支出', '发生额')) for h in htext):
                    score += 5
            if score > best_score:
                best_score = score
                best_rows = rows
                best_sheet = name
        if best_rows is None:
            raise UserError('{0}：工作簿里所有工作表都是空的。'.format(label))
        raw_rows = best_rows
        sheet_name = best_sheet
    finally:
        wb.close()

    rows = _trim_rows(raw_rows)
    candidates = _header_candidates(rows)
    if not candidates:
        raise UserError('{0}：在前 30 行里找不到表头。\n请确认第一行区域含有「日期 / 金额 / 摘要」这类列名。'.format(label))
    return {'path': path, 'sheet': sheet_name, 'rows': rows, 'candidates': candidates, 'label': label}


@dataclass
class Table:
    path: str
    sheet: str
    label: str
    headers: list = field(default_factory=list)
    rows: list = field(default_factory=list)          # [(excel_row_no, tuple)]
    colmap: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)


def _validate_mapping(mapping, headers, label):
    """检查列映射是否够用，返回问题描述；None 表示可用。"""
    if mapping['date'] < 0:
        return '没找到日期列'
    if mapping['mode'] == 'two':
        if mapping['inflow'] < 0 and mapping['outflow'] < 0:
            return '没找到金额列'
    elif mapping['mode'] == 'signed':
        if mapping['amount'] < 0:
            return '没找到金额列'
        if mapping['receiver'] < 0 and mapping['payer'] < 0:
            return '只有单列金额，但没找到收款人/付款人名称列'
    else:
        if mapping['amount'] < 0:
            return '没找到金额列'
        if mapping['flag'] < 0:
            return '只有一列金额，但没找到收/支标志列'
    return None


_AMOUNT_HINTS = ('原币金额', '交易金额', '发生额', '金额', 'amount')
_FLAG_VALUES = ('j', 'd', '借', '贷', '收', '付', '进', '出', '借j', '贷d')


def _filled_count(rows, index, sample=800):
    if index is None or index < 0:
        return 0
    hit = 0
    for _row_no, row in rows[:sample]:
        if _cell_has_value(_get(row, index)):
            hit += 1
    return hit


def _find_amount_column(table, exclude=()):
    used = set(i for i in exclude if i is not None and i >= 0)
    for cand in _AMOUNT_HINTS:
        key = clean_header(cand)
        for i, header in enumerate(table.headers):
            if i in used:
                continue
            if clean_header(header) == key:
                return i
    for i, header in enumerate(table.headers):
        if i in used:
            continue
        text = clean_header(header)
        if text.endswith('金额') and not text.startswith(('借', '贷', '收', '付')):
            return i
    return -1


_FLAG_HEADERS = ('收', '支', '收支', '收/支', '收付', '借/贷', '借贷', '方向', '标志',
                 '收付标志', '借贷标志', 'j', 'd', '借', '贷', 'dr', 'cr', 'debit', 'credit')
_PAIR_LEFT = ('j', '借', '借方', '收', '收入', '收方', '进', '进账', 'dr', 'debit')
_PAIR_RIGHT = ('d', '贷', '贷方', '付', '支出', '付方', '出', '出账', 'cr', 'credit')


def _find_flag_column(table, exclude=()):
    """找收/支标志列：取值集中在 J/D、借/贷、收/付 这类标记上。

    表头本身写着「收/支、借/贷、方向、J、D」的列优先；数据里标记值足够整齐的列其次。
    小表（只有几行）也允许命中，否则 2 行的样本永远判不出来。
    """
    used = set(i for i in exclude if i is not None and i >= 0)
    best_index, best_key = -1, None
    for i, header in enumerate(table.headers):
        if i in used:
            continue
        hit = 0
        total = 0
        for _row_no, row in table.rows[:400]:
            value = _get(row, i)
            if not _cell_has_value(value):
                continue
            total += 1
            if to_halfwidth(value).strip().lower() in _FLAG_VALUES:
                hit += 1
        if not total:
            continue
        ratio = hit / float(total)
        if ratio < 0.9:
            continue
        head_hint = 1 if clean_header(header).strip().lower() in _FLAG_HEADERS else 0
        if total < 3 and not head_hint:
            continue
        key = (head_hint, ratio)
        if best_key is None or key > best_key:
            best_index, best_key = i, key
    return best_index


def _pair_kind(table, left, right):
    """判断 J/D 这类「两列成对」的列装的是金额还是标记。"""
    filled = numeric = flag = 0
    for _row_no, row in table.rows[:400]:
        a = _get(row, left)
        b = _get(row, right)
        if not (_cell_has_value(a) or _cell_has_value(b)):
            continue
        filled += 1
        for value in (a, b):
            if not _cell_has_value(value):
                continue
            if parse_amount(value) is not None:
                numeric += 1
            elif to_halfwidth(value).strip().lower() in _FLAG_VALUES:
                flag += 1
    if not filled:
        return ''
    if numeric >= 0.8 * filled:
        return 'amount'
    if flag >= 0.8 * filled:
        return 'flag'
    return ''


def _find_flag_pair(table, exclude=()):
    """找「借/贷」两列成对的写法（如 J 列 + D 列），返回 (左, 右, 'amount'|'flag')。"""
    used = set(i for i in exclude if i is not None and i >= 0)
    cols = [i for i in range(len(table.headers)) if i not in used]

    def key(index):
        return clean_header(table.headers[index]).strip().lower()

    for left in cols:
        if key(left) not in _PAIR_LEFT:
            continue
        for right in cols:
            if right == left or key(right) not in _PAIR_RIGHT:
                continue
            kind = _pair_kind(table, left, right)
            if kind:
                return left, right, kind
    return None


def _merge_flag_pair(table, left, right):
    """把「两列各打标记」合并成一列借/贷标志，返回新列下标。"""
    table.rows = [(row_no, list(row)) for row_no, row in table.rows]
    width = max([len(table.headers)] + [len(row) for _row_no, row in table.rows])
    for _row_no, row in table.rows:
        while len(row) < width:
            row.append(None)
    new_index = width
    table.headers.append('借/贷')
    for _row_no, row in table.rows:
        if _cell_has_value(_get(row, left)):
            marker = '借'
        elif _cell_has_value(_get(row, right)):
            marker = '贷'
        else:
            marker = ''
        row.append(marker)
    return new_index



def refine_mapping(table, src):
    """按实际数据修正列映射，返回一条提示（没修正则返回空串）。

    真实账套里常见的两种「表头能识别、数据却对不上」：
    1) 有「借方金额 / 贷方金额」表头，但两列整列是空的，实际金额在「原币金额」，
       收付方向靠 J / D（借 / 贷）标记列；
    2) 只有一列金额，也没有收付标志列。
    """
    m = table.colmap
    rows = table.rows
    if not rows:
        return ''
    if m['mode'] == 'two':
        used_in = _filled_count(rows, m.get('inflow', -1))
        used_out = _filled_count(rows, m.get('outflow', -1))
        if used_in + used_out >= max(2, int(0.02 * min(len(rows), 800))):
            return ''
        amount_index = _find_amount_column(table, exclude=(m.get('inflow'), m.get('outflow')))
        if amount_index < 0:
            return '{0}：借方/贷方金额两列几乎都是空的，也没找到可用的单列金额，请检查表格。'.format(table.label)
        flag_index = _find_flag_column(table, exclude=(amount_index,))
        m['mode'] = 'single'
        m['amount'] = amount_index
        m['flag'] = flag_index
        m['inflow'] = -1
        m['outflow'] = -1
        pair = _find_flag_pair(table, exclude=(amount_index,))
        if pair:
            left, right, kind = pair
            if kind == 'amount':
                # J / D 两列放的是金额：日记账借方=收、贷方=支；流水相反
                inflow, outflow = (left, right) if src in ('journal', 'j') else (right, left)
                m['mode'] = 'two'
                m['inflow'] = inflow
                m['outflow'] = outflow
                m['amount'] = -1
                m['flag'] = -1
                return ('{0}：借方/贷方金额两列是空的，已改用「{1}」「{2}」两列按借/贷金额判断收付。'
                        ).format(table.label, table.headers[inflow], table.headers[outflow])
            m['flag'] = _merge_flag_pair(table, left, right)
            return ('{0}：借方/贷方金额两列是空的，已改用「{1}」+ 借/贷标记（「{2}」「{3}」两列）判断收付。'
                    ).format(table.label, table.headers[amount_index],
                             table.headers[left], table.headers[right])
        if flag_index < 0:
            return ('{0}：借方/贷方金额两列是空的，已改用「{1}」按金额正负判断收付；'
                    '没找到借/贷标志列，若金额全是正数请核对方向。').format(
                        table.label, table.headers[amount_index])
        return '{0}：借方/贷方金额两列是空的，已改用「{1}」+「{2}」按借/贷标志判断收付。'.format(
            table.label, table.headers[amount_index], table.headers[flag_index])
    if m['mode'] == 'single' and m.get('flag', -1) < 0:
        pair = _find_flag_pair(table, exclude=(m.get('amount'),))
        if pair:
            left, right, kind = pair
            if kind == 'flag':
                m['flag'] = _merge_flag_pair(table, left, right)
                return '{0}：找到「{1}」「{2}」两列的借/贷标记，按它判断收付方向。'.format(
                    table.label, table.headers[left], table.headers[right])
        flag_index = _find_flag_column(table, exclude=(m.get('amount'),))
        if flag_index >= 0:
            m['flag'] = flag_index
            return '{0}：找到借/贷标志列「{1}」，按它判断收付方向。'.format(
                table.label, table.headers[flag_index])
    return ''


def prepare_table(path, src):
    """读取并确定表结构；表头候选逐个试，直到映射可用。"""
    label = '日记账' if src == 'journal' else '银行流水'
    raw = read_table_raw(path, label)
    rows = raw['rows']
    last_problem = ''

    for header_idx in raw['candidates']:
        header_row = rows[header_idx]
        width = len(header_row)
        headers = []
        for i in range(width):
            if _cell_has_value(header_row[i]):
                headers.append(str(header_row[i]).strip())
            else:
                headers.append('列{0}'.format(i + 1))
        data = []
        for k in range(header_idx + 1, len(rows)):
            if not _row_has_value(rows[k]):
                continue
            data.append((k + 1, tuple(rows[k])))
        if not data:
            last_problem = '表头下面没有数据行'
            continue

        mapping = map_columns(headers, src)
        problem = _validate_mapping(mapping, headers, label)
        if problem:
            last_problem = problem
            continue

        table = Table(path=path, sheet=raw['sheet'], label=label,
                      headers=headers, rows=data, colmap=mapping)
        refine_note = refine_mapping(table, src)
        if refine_note:
            table.warnings.append(refine_note)
        if mapping['name'] < 0 and mapping['mode'] != 'signed':
            table.warnings.append('{0}：没识别出「对方/户名」列，只能按金额、日期和摘要匹配，准确率会下降。'.format(label))
        if mapping['mode'] == 'two':
            if mapping['inflow'] < 0:
                table.warnings.append('{0}：只识别出支出列，收入列缺失（若确实只有一类可忽略）。'.format(label))
            if mapping['outflow'] < 0:
                table.warnings.append('{0}：只识别出收入列，支出列缺失（若确实只有一类可忽略）。'.format(label))
        elif mapping['mode'] == 'signed':
            if mapping['receiver'] < 0:
                table.warnings.append('{0}：只识别出付款人列，收款人列缺失（金额为负的支出行对方名称会为空）。'.format(label))
            if mapping['payer'] < 0:
                table.warnings.append('{0}：只识别出收款人列，付款人列缺失（金额为正的收入行对方名称会为空）。'.format(label))
        return table

    raise UserError(
        '{0}：自动识别表头失败（{1}）。\n'
        '可以这样处理：①删掉表格上方的标题行，让列名单独占一行；'
        '②或把列名改成「交易日期 / 对方户名 / 借方金额 / 贷方金额」这类标准写法。'.format(label, last_problem)
    )


# ---------------------------------------------------------------------------
# 生成待匹配记录
# ---------------------------------------------------------------------------

@dataclass(eq=False)
class Txn:
    src: str                # 'j' 日记账 / 'b' 流水
    row_no: int
    direction: str          # '收' / '支'
    cents: int
    d: object               # date | None
    name: str
    raw_name: str
    summary: str
    voucher: str = ''       # 凭证号（日记账通常有，流水常无）
    index_no: str = ''      # 索引号 / 序号（源表自带，方便日后查找）
    used: bool = False
    match_id: int = 0
    match_type: str = ''
    note: str = ''


def direction_from_flag(value, src):
    """按收/支标志判断方向；日记账与流水的借贷方向相反。"""
    if value is None:
        return None
    s = to_halfwidth(value).strip().lower()
    if not s:
        return None
    # 单字母 J / D 按拼音当「借 / 贷」处理（中文账套导出比英文 Debit/Credit 更常见）
    credit_like = ('收', '收入', '进', '进账', '存入', '贷记', '贷', '贷方', '+', '1', '1.0', 'c', 'cr', 'd')
    debit_like = ('付', '支出', '出', '付出', '支取', '借记', '借', '借方', '-', '-1', '2', 'j', 'dr')
    if s in credit_like:
        kind = 'credit'
    elif s in debit_like:
        kind = 'debit'
    else:
        return None
    if src in ('journal', 'j'):
        return '收' if kind == 'debit' else '支'
    return '收' if kind == 'credit' else '支'


def _flip(direction):
    return '支' if direction == '收' else '收'


def _signed_direction_hint(table, exclude_names=None):
    """单列金额的流水表：判断收付方向该怎么定。

    返回 (self_name, has_negative)：
    - has_negative 为 True 时按金额正负判断，self_name 不用；
    - 金额全是正数时，本公司户名一定会出现在「付款人」或「收款人」某一侧，
      取两列里出现次数最多的名字作为本公司名：付款人=本公司 → 付款；
      收款人=本公司 → 收款。
    exclude_names 是日记账里出现过的对方户名——本公司自己的名字不会成为
    日记账的对方户名，用它可以把「两边都出现」的歧义消掉。
    """
    mapping = table.colmap
    has_negative = False
    payer_count = defaultdict(int)
    receiver_count = defaultdict(int)
    total = 0
    for _row_no, row in table.rows:
        total += 1
        cents = parse_amount(_get(row, mapping.get('amount', -1)))
        if cents is not None and cents < 0:
            has_negative = True
        payer = normalize_name(_get(row, mapping.get('payer', -1)))
        receiver = normalize_name(_get(row, mapping.get('receiver', -1)))
        if payer:
            payer_count[payer] += 1
        if receiver:
            receiver_count[receiver] += 1
    if has_negative or total == 0:
        return '', has_negative
    names = set(payer_count) | set(receiver_count)
    if not names:
        return '', has_negative
    excluded = set(exclude_names or ())
    candidates = names - excluded
    if candidates:
        names = candidates
    floor = max(2, int(0.5 * total))
    # 本公司户名通常两边都出现：收钱时在收款人一侧，付钱时在付款人一侧。
    both_sides = [n for n in names
                  if payer_count[n] and receiver_count[n]
                  and payer_count[n] + receiver_count[n] >= floor]
    if both_sides:
        return max(both_sides, key=lambda n: payer_count[n] + receiver_count[n]), has_negative
    name, count = max(((n, payer_count[n] + receiver_count[n]) for n in names),
                      key=lambda kv: kv[1])
    if count < floor:
        return '', has_negative
    return name, has_negative


def build_txns(table, src, counterparty_names=None):
    """把表格行转成 Txn 列表；同时记录无法参与匹配的行及原因。

    counterparty_names：日记账里出现过的对方户名，用来帮流水判断本公司户名。
    """
    txns = []
    ignored = {}
    warnings = []
    mapping = table.colmap
    label = table.label

    self_name, has_negative = '', False
    if mapping['mode'] == 'signed':
        self_name, has_negative = _signed_direction_hint(table, counterparty_names)
        if not self_name and not has_negative:
            warnings.append(
                '{0}：交易金额全是正数，也没能识别出本公司户名，收付方向可能判断反了，请核对后再用结果。'.format(label))

    for row_no, row in table.rows:
        if not _row_has_value(row):
            continue

        day = parse_date(_get(row, mapping['date']))
        if day is None:
            warnings.append('{0} 第 {1} 行日期无法识别：{2!r}'.format(label, row_no, _get(row, mapping['date'])))

        name_raw = _get(row, mapping['name'])
        name = normalize_name(name_raw)
        summary = _get(row, mapping['summary'])
        summary = '' if summary is None else str(summary).strip()
        voucher_raw = _get(row, mapping.get('voucher', -1))
        voucher = '' if voucher_raw is None else str(voucher_raw).strip()
        index_raw = _get(row, mapping.get('index', -1))
        index_no = '' if index_raw is None else str(index_raw).strip()

        pairs = []
        if mapping['mode'] == 'signed':
            # 单列交易金额：有负数就按正负判断；全是正数则看本公司出现在付款人还是收款人一侧
            cents = parse_amount(_get(row, mapping['amount']))
            if cents is None:
                ignored[(src, row_no)] = '金额无法识别'
                continue
            if cents == 0:
                ignored[(src, row_no)] = '金额为 0'
                continue
            payer = normalize_name(_get(row, mapping['payer']))
            receiver = normalize_name(_get(row, mapping['receiver']))
            if cents < 0:
                direction = '支'
                name_raw = _get(row, mapping['receiver'])
                cents = -cents
            elif self_name and payer == self_name and receiver:
                # 付款人是本公司 -> 这笔钱付出去了，对方=收款人
                direction = '支'
                name_raw = _get(row, mapping['receiver'])
            elif self_name and receiver == self_name and payer:
                # 收款人是本公司 -> 这笔钱收进来了，对方=付款人
                direction = '收'
                name_raw = _get(row, mapping['payer'])
            else:
                direction = '收'
                name_raw = _get(row, mapping['payer'])
            name = normalize_name(name_raw)
            pairs.append((direction, cents))
        elif mapping['mode'] == 'single':
            cents = parse_amount(_get(row, mapping['amount']))
            if cents is None:
                ignored[(src, row_no)] = '金额无法识别'
                continue
            if cents == 0:
                ignored[(src, row_no)] = '金额为 0'
                continue
            direction = direction_from_flag(_get(row, mapping['flag']), src)
            if direction is None:
                direction = '收' if cents > 0 else '支'
                warnings.append('{0} 第 {1} 行收/支标志无法识别（{2!r}），按金额正负判断'.format(
                    label, row_no, _get(row, mapping['flag'])))
            if cents < 0:
                cents = -cents
                direction = _flip(direction)
            pairs.append((direction, cents))
        else:
            for key, direction in (('inflow', '收'), ('outflow', '支')):
                idx = mapping.get(key, -1)
                if idx is None or idx < 0:
                    continue
                raw_value = _get(row, idx)
                cents = parse_amount(raw_value)
                if cents is None:
                    if _cell_has_value(raw_value):
                        warnings.append('{0} 第 {1} 行金额无法识别：{2!r}'.format(label, row_no, raw_value))
                    continue
                if cents == 0:
                    continue
                if cents < 0:
                    cents = -cents
                    direction = _flip(direction)
                pairs.append((direction, cents))
            if not pairs:
                ignored[(src, row_no)] = '金额为空或为 0'
                continue

        for direction, cents in pairs:
            txns.append(Txn(src=src, row_no=row_no, direction=direction, cents=cents,
                            d=day, name=name, raw_name='' if name_raw is None else str(name_raw).strip(),
                            summary=summary, voucher=voucher, index_no=index_no))

    return txns, ignored, warnings


# ---------------------------------------------------------------------------
# 匹配
# ---------------------------------------------------------------------------

WEAK_SIM = 0.55           # 一侧缺名称时的「弱证据」得分


def _sim(j, b):
    """两笔记录的户名相似度；一侧缺名称时给弱证据分。"""
    if j.name and b.name:
        return name_similarity(j.name, b.name)
    return WEAK_SIM


def _day_delta(j, b):
    """日期差（天）；任一侧没有日期按 0 处理。"""
    if j.d is not None and b.d is not None:
        return abs((b.d - j.d).days)
    return 0


def name_pair_ok(j, b, threshold):
    """户名硬判据：任一侧没名称就放行，两侧都有名称则必须达到阈值。

    这是 v2.2 相对旧版最关键的改动——旧版把户名只当排序分，金额相同就敢配。
    """
    if not j.name or not b.name:
        return True
    return name_similarity(j.name, b.name) >= threshold


def find_subset(items, target, limit, budget, timeout=1.0):
    """在候选里找一个组合，使金额之和等于 target（最多 limit 笔）。

    items 由调用方按偏好排好序（户名越像越靠前）；内部按金额降序稳定排序，
    让大额先试、快速命中。timeout 为软超时（秒），budget[0] 为节点预算。
    """
    cand = [c for c in items if 0 < c.cents <= target]
    if len(cand) < 2:
        return None
    if sum(c.cents for c in cand) < target:
        return None
    cand.sort(key=lambda t: -t.cents)
    n = len(cand)
    suffix = [0] * (n + 1)
    for i in range(n - 1, -1, -1):
        suffix[i] = suffix[i + 1] + cand[i].cents
    chosen = []
    deadline = time.time() + timeout

    def dfs(start, remaining):
        if remaining == 0:
            return True
        if len(chosen) >= limit or start >= n:
            return False
        if suffix[start] < remaining:
            return False
        for i in range(start, n):
            if suffix[i] < remaining:
                return False
            if time.time() > deadline:
                return False
            budget[0] -= 1
            if budget[0] <= 0:
                return False
            cents = cand[i].cents
            if cents > remaining:
                continue
            chosen.append(cand[i])
            if dfs(i + 1, remaining - cents):
                return True
            chosen.pop()
        return False

    return list(chosen) if dfs(0, target) else None


def _link(group, groups, new_id, match_type):
    gid = new_id()
    for txn in group:
        txn.used = True
        txn.match_id = gid
        txn.match_type = match_type
    groups[gid] = list(group)
    return gid


_TOKEN_RE = re.compile(r'[A-Za-z0-9]{4,}')


def _summary_tokens(txn):
    """摘要里能用来区分单据的编号（单号、发票号、流水号…）。

    只在「金额、户名、日期都一样」的候选之间做最后的区分，不影响主判据。
    """
    tokens = getattr(txn, '_tok', None)
    if tokens is None:
        tokens = frozenset(m.group(0).upper() for m in _TOKEN_RE.finditer(txn.summary or ''))
        txn._tok = tokens
    return tokens


def _assign_pairs(jlist, blist, opts, tol_cents=0):
    """同一个 (方向, 金额) 桶内的一对一分配：Kuhn 增广路，按可信度占位。

    返回 [(j, b, sim, delta)]。被抢走的候选会沿增广路改配，
    所以不会出现「先遍历到的记录把最优候选占走」的连锁错配。

    先用日期把候选缩到 ±窗口内，再做名称比较，避免大桶上的平方级计算。
    """
    threshold = opts.name_threshold
    window = opts.date_window
    by_day = defaultdict(list)
    for b in blist:
        by_day[b.d].append(b)

    adj = {}
    for j in jlist:
        if j.d is None:
            pool = list(blist)
        else:
            pool = []
            for off in range(-window, window + 1):
                pool.extend(by_day.get(j.d + timedelta(days=off), ()))
        cands = []
        for b in pool:
            if tol_cents:
                gap = abs(j.cents - b.cents)
                if gap == 0 or gap > tol_cents:
                    continue
            elif j.cents != b.cents:
                continue
            delta = _day_delta(j, b)
            if delta > window:
                continue
            if getattr(opts, 'name_strict', True) and not name_pair_ok(j, b, threshold):
                continue
            sim = _sim(j, b)
            affinity = 0.02 if (_summary_tokens(j) & _summary_tokens(b)) else 0.0
            cands.append((sim - 0.02 * delta + affinity, sim, delta, b))
        if cands:
            cands.sort(key=lambda x: (-x[0], x[3].d or date.min, x[3].row_no))
            adj[j] = cands
    if not adj:
        return []

    matched = {}          # id(b) -> (j, sim, delta, b)

    def augment(j, seen):
        for _score, sim, delta, b in adj[j]:
            key = id(b)
            if key in seen:
                continue
            seen.add(key)
            if key not in matched or augment(matched[key][0], seen):
                matched[key] = (j, sim, delta, b)
                return True
        return False

    old_limit = sys.getrecursionlimit()
    if old_limit < 20000:
        sys.setrecursionlimit(20000)
    try:
        for j in sorted(adj, key=lambda t: (len(adj[t]), t.d or date.min, t.row_no)):
            augment(j, set())
    finally:
        if old_limit < 20000:
            sys.setrecursionlimit(old_limit)
    return [(item[0], item[3], item[1], item[2]) for item in matched.values()]


def _profile_pass(jtx, btx, window, threshold, flip=False):
    """匹配前体检：方向、金额、日期、户名四道关各能过多少笔。"""
    index = defaultdict(list)
    for b in btx:
        if b.d is None:
            continue
        direction = _flip(b.direction) if flip else b.direction
        index[(direction, b.cents)].append(b)
    facts = {'total': len(jtx), 'amount': 0, 'date': 0, 'name': 0,
             'deltas': [], 'strong_deltas': []}
    for j in jtx:
        cands = index.get((j.direction, j.cents))
        if not cands:
            continue
        facts['amount'] += 1
        best, best_delta = None, None
        for b in cands[:40]:
            delta = _day_delta(j, b)
            if best_delta is None or delta < best_delta:
                best, best_delta = b, delta
        if best is None:
            continue
        # 日期差不论是否落在当前窗口内都要收集：否则窗口过紧时永远发现不了该放宽
        facts['deltas'].append(best_delta)
        name_ok = name_pair_ok(j, best, threshold)
        if name_ok:
            # 户名能对上的这几笔，日期差才可信：用它来估计真实的到账滞后
            facts['strong_deltas'].append(best_delta)
        if best_delta > window:
            continue
        facts['date'] += 1
        if name_ok:
            facts['name'] += 1
    return facts


def _internal_transfer_pairs(jtx, max_days=3):
    """日记账里「同额、一收一支」的组合，多半是账户间划转（不会在本账户流水里）。"""
    buckets = defaultdict(lambda: ([], []))
    for t in jtx:
        buckets[t.cents][0 if t.direction == '收' else 1].append(t)
    pairs = 0
    total = 0
    for cents, (ins, outs) in buckets.items():
        if not ins or not outs:
            continue
        used_in, used_out = set(), set()
        for a in ins:
            for b in outs:
                if id(a) in used_in or id(b) in used_out:
                    continue
                if _day_delta(a, b) <= max_days:
                    used_in.add(id(a))
                    used_out.add(id(b))
                    pairs += 1
                    total += cents
                    break
    return pairs, total


def auto_tune(jtx, btx, opts, warnings):
    """按数据本身自动校正三处容易整体错位的地方，返回 (新 options, 体检数字)。

    1) 收付方向整体反了：流水金额全是正数、又没认出本公司名时最容易出现；
    2) 日期容差太紧：钱到账常比记账晚几天，1 天窗口会把大半账挡在外面；
    3) 户名写法差太多：日记账写简称、流水是全称，硬性要求户名一致就整份配不上，
       改为「先按方向+金额+日期配对，户名不符的标成待复核」。
    """
    total = len(jtx)
    window = int(opts.date_window)
    tuned = replace(opts)
    base = _profile_pass(jtx, btx, window, opts.name_threshold, flip=False)
    facts = {
        '总笔数': total,
        '金额能对上': base['amount'],
        '日期能对上': base['date'],
        '户名能对上': base['name'],
        '方向自动对调': False,
        '日期容差': window,
        '严格户名': True,
    }

    if total and base['amount'] < 0.2 * total:
        flipped = _profile_pass(jtx, btx, window, opts.name_threshold, flip=True)
        if flipped['amount'] > max(3, 2 * base['amount']) and flipped['amount'] >= 0.5 * total:
            for b in btx:
                b.direction = _flip(b.direction)
            base = flipped
            facts['金额能对上'] = base['amount']
            facts['日期能对上'] = base['date']
            facts['户名能对上'] = base['name']
            facts['方向自动对调'] = True
            warnings.append(
                '银行流水的收付方向和日记账正好相反，已自动对调后再匹配。'
                '请顺便核对「左右并列核对」里前几行的收/支是否符合实际。')

    deltas = sorted(base['strong_deltas'] or base['deltas'])
    if len(deltas) >= 20:
        p90 = deltas[int(0.9 * (len(deltas) - 1))]
        if p90 > window:
            tuned.date_window = max(window, min(int(p90), 45))
            facts['日期容差'] = tuned.date_window
            warnings.append(
                '钱到账常比记账晚，日期容差按数据分布自动放宽到 {0} 天'
                '（90% 的记录在 {0} 天内到账）。'.format(tuned.date_window))
            base = _profile_pass(jtx, btx, tuned.date_window, opts.name_threshold, flip=False)
            facts['日期能对上'] = base['date']
            facts['户名能对上'] = base['name']

    if base['date'] >= 20:
        ratio = base['name'] / float(base['date'])
        facts['户名能对上率'] = ratio
        if ratio < 0.5:
            tuned.name_strict = False
            facts['严格户名'] = False
            warnings.append(
                '两侧户名写法差异较大，只有 {0:.0%} 能对上（日记账常写简称，流水是全称）。'
                '已改为先按「方向+金额+日期」配对：户名不符的会在「方式」列标「金额匹配」、'
                '「户名核对」列标「否」，请重点复核这些行。'.format(ratio))

    # 户名靠不住时，同金额多笔只能按日期就近配，可能错位——先说清楚，别让人误以为全对
    same = defaultdict(int)
    for j in jtx:
        same[(j.direction, j.cents)] += 1
    dup = sum(1 for v in same.values() if v > 1)
    facts['同金额多笔'] = dup
    if not tuned.name_strict and dup:
        warnings.append(
            '另有 {0} 组「方向+金额」完全相同的记录，这类配对只能按日期远近确定，'
            '存在错位可能：请在「左右并列核对」里按「户名核对」列筛选「否」逐笔复核。'.format(dup))

    # 日记账比流水多出来的那些行，本来就不可能在流水里找到对应记录
    facts['日记账笔数'] = len(jtx)
    facts['流水笔数'] = len(btx)
    facts['笔数差'] = max(0, len(jtx) - len(btx))
    trans_pairs, trans_total = _internal_transfer_pairs(jtx)
    facts['疑似内部划转组数'] = trans_pairs
    facts['疑似内部划转金额'] = trans_total / 100.0
    if trans_pairs >= 5:
        warnings.append(
            '日记账里有 {0} 组「同额、一收一支」的记录（合计 {1:,.2f} 元），'
            '很像账户之间的内部划转；这类记录不会出现在本账户的流水里，'
            '会一直留在待查中，属正常现象。'.format(trans_pairs, trans_total / 100.0))
    return tuned, facts


def match_all(jtx, btx, opts, report=None, cancel=None):
    """分层匹配，返回 {组号: [Txn, ...]}。

    第 1 层 一对一：金额完全相等 + 户名达标（桶内全局分配，不按文件顺序抢）
    第 2 层 一对一：金额在容差内 + 户名达标
    第 3 层 一对多：一笔日记账 = 多笔流水（同户名候选内做子集和，按候选少者优先）
    第 4 层 多对一：多笔日记账 = 一笔流水
    第 5 层 兜底：金额日期一致、双向唯一但名称不符 → 标「唯一候选」，方便复核

    户名是硬判据：两侧都有名称且相似度低于阈值时绝不配对；
    只有一侧没有名称时，才允许仅凭「方向 + 金额 + 日期」匹配，并标成「金额匹配」。
    若匹配前的体检发现两侧户名大面积对不上（日记账写简称、流水是全称），
    opts.name_strict 会被 auto_tune 置为 False：此时允许凭金额+日期配对，
    但每一对都标成「金额匹配」并在「户名核对」列显示「否」，交人工复核。
    """
    counter = [0]
    groups = {}

    def new_id():
        counter[0] += 1
        return counter[0]

    def check_cancel():
        if cancel is not None and cancel.is_set():
            raise UserError('已取消')

    def emit(message, percent=None):
        if report:
            report(message, percent)

    threshold = opts.name_threshold
    window = opts.date_window
    # 合并匹配放宽几天：一笔付款拆成几笔到账，跨 2-3 天很常见（有户名约束兜底）
    group_window = max(window, int(getattr(opts, 'group_window', 3) or 0))
    tol = int(round(opts.amount_tol * 100))

    j_by_amount = defaultdict(list)
    for j in jtx:
        j_by_amount[(j.direction, j.cents)].append(j)
    b_by_amount = defaultdict(list)
    for b in btx:
        b_by_amount[(b.direction, b.cents)].append(b)

    def commit(pairs, tolerance=False):
        for j, b, sim, delta in pairs:
            if j.used or b.used:
                continue
            if tolerance:
                kind = '容差'
            elif sim >= 0.999:
                kind = '精确'
            elif j.name and b.name and sim < threshold:
                # 放宽模式下靠金额+日期配上的，户名对不上：单独标出来，便于复核
                kind = '金额匹配'
                if not j.note:
                    j.note = '户名与流水对不上（相似度 {0:.2f}），凭金额和日期配对，请复核'.format(sim)
                if not b.note:
                    b.note = '户名与日记账对不上（相似度 {0:.2f}），凭金额和日期配对，请复核'.format(sim)
            elif j.name and b.name:
                kind = '名称匹配'
            else:
                kind = '金额匹配'
            _link([j, b], groups, new_id, kind)

    # ---------- 第 1 层：金额完全相等 ----------
    emit('一对一匹配（金额相同 + 户名核对）…', 34)
    keys = sorted(set(j_by_amount) | set(b_by_amount))
    for n, key in enumerate(keys):
        if n % 400 == 0:
            check_cancel()
        jl = [j for j in j_by_amount.get(key, ()) if not j.used]
        bl = [b for b in b_by_amount.get(key, ()) if not b.used]
        if jl and bl:
            commit(_assign_pairs(jl, bl, opts, 0))

    # ---------- 第 2 层：金额容差 ----------
    if tol > 0:
        emit('容差匹配（金额相差 {0:.2f} 元内）…'.format(opts.amount_tol), 44)
        cents_index = defaultdict(list)
        for b in btx:
            if not b.used:
                cents_index[(b.direction, b.cents)].append(b)
        done = 0
        for j in jtx:
            if j.used:
                continue
            done += 1
            if done % 200 == 0:
                check_cancel()
            cand = []
            for diff in range(1, tol + 1):
                for cents in (j.cents - diff, j.cents + diff):
                    for b in cents_index.get((j.direction, cents), ()):
                        if (not b.used and _day_delta(j, b) <= window
                                and (not getattr(opts, 'name_strict', True)
                                     or name_pair_ok(j, b, threshold))):
                            cand.append(b)
            if cand:
                commit(_assign_pairs([j], cand, opts, tol), tolerance=True)

    # ---------- 第 2.5 层：小额差额（手续费、净额到账） ----------
    fee_cap = int(getattr(opts, 'fee_cap', 0) or 0)
    if fee_cap > 0:
        emit('核对小额差额（手续费 / 净额到账）…', 48)
        ratio = float(getattr(opts, 'fee_ratio', 0.002) or 0)
        span = max(int(getattr(opts, 'fee_days', 2) or 0), min(window, 7))
        fee_index = defaultdict(list)
        for t in jtx + btx:
            if t.d is not None:
                fee_index[(t.direction, t.d)].append(t)

        def fee_pass(anchors):
            got = 0
            for a in anchors:
                if a.used or a.d is None:
                    continue
                limit = min(fee_cap, max(2000, int(a.cents * ratio)))
                cands = []
                for off in range(-span, span + 1):
                    for b in fee_index.get((a.direction, a.d + timedelta(days=off)), ()):
                        if b.used or b is a or b.src == a.src:
                            continue
                        diff = abs(a.cents - b.cents)
                        if diff == 0 or diff > limit:
                            continue
                        sim = _sim(a, b)
                        # 差几元以内凭日期+户名即可；差到几十元就必须户名高度相似
                        need = WEAK_SIM if diff <= 500 else max(threshold, 0.85)
                        if a.name and b.name and sim < need:
                            continue
                        cands.append((diff, abs(off), -sim, b))
                if not cands:
                    continue
                cands.sort()
                if len(cands) > 1 and cands[0][:2] == cands[1][:2]:
                    # 差额一样近，分不清是哪一笔，宁可留给人工
                    continue
                b = cands[0][3]
                delta_yuan = (b.cents - a.cents) / 100.0
                note = ('金额相差 {0:+,.2f} 元（可能是手续费或净额到账），'
                        '已按差额最小的一笔配对，请复核').format(delta_yuan)
                if not a.note:
                    a.note = note
                if not b.note:
                    b.note = note
                _link([a, b], groups, new_id, '部分匹配')
                got += 1
            return got

        fee_gain = fee_pass([t for t in jtx if not t.used])
        fee_gain += fee_pass([t for t in btx if not t.used])
        if fee_gain:
            emit('小额差额配对 {0} 笔（请在「方式」列筛「部分匹配」复核）'.format(fee_gain))

    # ---------- 第 3 / 4 层：合并匹配（一笔对多笔） ----------
    j_by_day = defaultdict(list)
    b_by_day = defaultdict(list)
    for t in jtx:
        j_by_day[(t.direction, t.d)].append(t)
    for t in btx:
        b_by_day[(t.direction, t.d)].append(t)

    def pool_of(anchor, index, span=None):
        if anchor.d is None:
            return []
        span = window if span is None else span
        out = []
        for off in range(-span, span + 1):
            for t in index.get((anchor.direction, anchor.d + timedelta(days=off)), ()):
                if t is anchor or t.used:
                    continue
                if not (0 < t.cents <= anchor.cents):
                    continue
                if getattr(opts, 'name_strict', True) and not name_pair_ok(anchor, t, threshold):
                    continue
                out.append(t)
        return out

    def run_group_pass(anchors, index, label, percent):
        emit(label, percent)
        limits = [2, 3]
        if opts.group_limit > 3:
            limits.append(opts.group_limit)
        deadline = time.time() + opts.group_seconds

        def try_anchor(anchor, pool):
            pool = [t for t in pool if not t.used]
            if len(pool) < 2:
                return False
            pool.sort(key=lambda t: (-_sim(anchor, t), -t.cents, t.row_no))
            picked = None
            anchor_tokens = _summary_tokens(anchor)
            # 摘要里有相同单号/发票号的候选优先；凑不出再退回全池
            token_pool = [t for t in pool if anchor_tokens & _summary_tokens(t)]
            rounds = [token_pool, pool] if len(token_pool) >= 2 else [pool]
            for run_pool in rounds:
                budget = [opts.group_budget]
                for lim in limits:
                    if lim > len(run_pool):
                        continue
                    picked = find_subset(run_pool, anchor.cents, lim, budget, timeout=0.25)
                    if picked:
                        break
                if picked:
                    break
            if picked and len(picked) >= 2:
                _link([anchor] + list(picked), groups, new_id, '组匹配')
                return True
            return False

        def sweep(span):
            todo = []
            for a in anchors:
                if a.used or a.d is None:
                    continue
                pool = pool_of(a, index, span)
                if 2 <= len(pool) <= opts.pool_cap:
                    todo.append((len(pool), a, pool))
                elif len(pool) > opts.pool_cap and not a.note:
                    a.note = '同户名候选 {0} 笔（超过上限 {1}），未做合并匹配，请手工核对'.format(
                        len(pool), opts.pool_cap)
            todo.sort(key=lambda x: (x[0], x[1].d or date.min, x[1].row_no))
            for n, (_size, anchor, pool) in enumerate(todo):
                if anchor.used:
                    continue
                if n % 20 == 0:
                    check_cancel()
                if time.time() > deadline:
                    if not anchor.note:
                        anchor.note = '合并匹配超时，请手工核对'
                    continue
                try_anchor(anchor, pool)

        # 先按「日期容差」做一轮，剩下的再放宽到 group_window
        sweep(window)
        if group_window > window:
            sweep(group_window)

    run_group_pass([t for t in jtx if not t.used], b_by_day,
                   '合并匹配（一笔日记账 vs 多笔流水）…', 52)
    run_group_pass([t for t in btx if not t.used], j_by_day,
                   '合并匹配（多笔日记账 vs 一笔流水）…', 60)

    # ---------- 第 5 层：兜底（双向唯一且户名对得上） ----------
    if opts.fallback_unique:
        emit('兜底匹配（金额日期一致且双向唯一）…', 66)
        j_un = defaultdict(list)
        for t in jtx:
            if not t.used:
                j_un[(t.direction, t.cents)].append(t)
        b_un = defaultdict(list)
        for t in btx:
            if not t.used:
                b_un[(t.direction, t.cents)].append(t)
        keys = [k for k in b_un
                if k in j_un and len(j_un[k]) <= 50 and len(b_un[k]) <= 50]
        keys.sort()
        weak_skipped = 0
        for n, key in enumerate(keys):
            if n % 200 == 0:
                check_cancel()
            jl = [t for t in j_un[key] if not t.used]
            bl = [t for t in b_un[key] if not t.used]
            if len(jl) != 1 or len(bl) != 1:
                continue
            j, b = jl[0], bl[0]
            if _day_delta(j, b) > window:
                continue
            # 户名完全对不上的，宁可不配：错配比漏配更难查
            if j.name and b.name and _sim(j, b) < WEAK_SIM:
                weak_skipped += 1
                if not j.note:
                    j.note = '金额、日期唯一但对方户名对不上，未自动匹配，请手工核对'
                if not b.note:
                    b.note = '金额、日期唯一但对方户名对不上，未自动匹配，请手工核对'
                continue
            _link([j, b], groups, new_id, '唯一候选')
        if weak_skipped >= 3:
            emit('提示：{0} 对记录金额、日期唯一但户名对不上，已留在未匹配里'
                 '（可在「待查手工核对」页确认）'.format(weak_skipped), 67)

    return groups


def explain_unmatched(jtx, btx, opts=None):
    """给未匹配的记录标注可能原因，便于人工排查（带时间预算，避免大数据卡顿）。"""
    window = opts.date_window if opts is not None else 1
    budget_left = [120.0]          # 总时间预算（秒），超时即停止标注，其余保持默认
    SIM_CHECK_CAP = 200            # 单条记录同一天名称相似度最多比对候选数，防平方爆炸

    def _has_time():
        if budget_left[0] <= 0:
            return False
        if time.time() - budget_left[1] > budget_left[0]:
            budget_left[0] = 0
            return False
        return True

    def _name_similar_in(lst, name, max_cmp):
        """在候选里找相似名称；只比对前 max_cmp 个，够判断即可。"""
        if not name:
            return True
        done = 0
        for b in lst:
            if done >= max_cmp:
                break
            done += 1
            if name_similarity(name, b.name) >= 0.7:
                return True
        return False

    budget_left.append(time.time())
    bank_by_amount = defaultdict(list)
    bank_by_day = defaultdict(list)
    for b in btx:
        if not b.used:
            bank_by_amount[(b.direction, b.cents)].append(b)
            bank_by_day[(b.direction, b.d)].append(b)

    for j in jtx:
        if j.used:
            continue
        if not _has_time():
            break
        same_amount = bank_by_amount.get((j.direction, j.cents), [])
        if same_amount:
            # 有同金额流水但未匹配：说明要么日期超容差，要么已被其他日记账认领/金额重复
            if any(b.d == j.d for b in same_amount):
                j.note = '同日同金额但未匹配（该金额可能已匹配给其他记录）'
            elif any(b.d is not None and j.d is not None and abs((b.d - j.d).days) <= window
                     for b in same_amount):
                j.note = '日期超出容差'
            else:
                j.note = '日期不符'
            continue
        same_day = bank_by_day.get((j.direction, j.d), [])
        if _name_similar_in(same_day, j.name, SIM_CHECK_CAP):
            j.note = '金额不符'
        else:
            j.note = '单边未达'

    journal_by_amount = defaultdict(list)
    journal_by_day = defaultdict(list)
    for j in jtx:
        if not j.used:
            journal_by_amount[(j.direction, j.cents)].append(j)
            journal_by_day[(j.direction, j.d)].append(j)

    for b in btx:
        if b.used:
            continue
        if not _has_time():
            break
        same_amount = journal_by_amount.get((b.direction, b.cents), [])
        if same_amount:
            if any(j.d == b.d for j in same_amount):
                b.note = '同日同金额但未匹配（该金额可能已匹配给其他记录）'
            elif any(j.d is not None and b.d is not None and abs((j.d - b.d).days) <= window
                     for j in same_amount):
                b.note = '日期超出容差'
            else:
                b.note = '日期不符'
            continue
        same_day = journal_by_day.get((b.direction, b.d), [])
        if _name_similar_in(same_day, b.name, SIM_CHECK_CAP):
            b.note = '金额不符'
        else:
            b.note = '单边未达'


# ---------------------------------------------------------------------------
# 结果汇总与导出
# ---------------------------------------------------------------------------

@dataclass
class Result:
    j_table: object
    b_table: object
    j_txns: list
    b_txns: list
    groups: dict
    ignored: dict
    warnings: list
    options: object
    elapsed: float
    j_fp: str
    b_fp: str
    diagnosis: dict = field(default_factory=dict)


STATUS_ORDER = ('已匹配', '组匹配', '部分匹配', '待查', '未参与')


def build_row_summary(res, src):
    """每行的匹配结论：状态、组号、方式、关联笔数、匹配金额、差额、说明。"""
    txns = res.j_txns if src == 'j' else res.b_txns
    by_row = defaultdict(list)
    for t in txns:
        by_row[t.row_no].append(t)
    ignored = {row_no: note for (s, row_no), note in res.ignored.items() if s == src}

    summary = {}
    for row_no in set(by_row) | set(ignored):
        lst = by_row.get(row_no, [])
        if not lst:
            summary[row_no] = ('未参与', '', '', 0, 0, ignored.get(row_no, ''), 0)
            continue

        matched = [t for t in lst if t.used]
        gids = sorted({t.match_id for t in matched})
        gsize = max((len(res.groups.get(gid, ())) for gid in gids), default=0)
        if not matched:
            status = '待查'
        elif len(matched) == len(lst):
            status = '组匹配' if gsize > 2 else '已匹配'
        else:
            status = '部分匹配'

        partner_cents = 0
        partner_count = 0
        for gid in gids:
            for other in res.groups.get(gid, ()):
                if other.src != src:
                    partner_cents += other.cents
                    partner_count += 1

        own_cents = sum(t.cents for t in lst)
        if status == '待查':
            matched_cents = 0
            diff = own_cents
        else:
            # 差额按实际对侧金额算：单笔、合并、手工配对都一致，不再把它硬写成 0
            matched_cents = partner_cents
            diff = own_cents - partner_cents

        note = ''
        if status != '已匹配':
            note = next((t.note for t in lst if not t.used and t.note), '')
        if not note and matched:
            mtype = matched[0].match_type
            if mtype == '唯一候选':
                note = '名称不一致，但金额、日期双向唯一，按唯一候选配对，建议复核'
            elif mtype == '金额匹配':
                note = '至少一侧没有对方名称，只能按金额、日期配对，建议复核'
            elif mtype == '手工':
                note = '手工核对确认'
        summary[row_no] = (status, 'M{0:04d}'.format(gids[0]) if gids else '',
                           matched[0].match_type if matched else '',
                           partner_count, matched_cents, note, diff)
    return summary


def compute_stats(res):
    j_summary = build_row_summary(res, 'j')
    b_summary = build_row_summary(res, 'b')

    def count(summary, status):
        return sum(1 for v in summary.values() if v[0] == status)

    def total(txns, direction):
        return sum(t.cents for t in txns if t.direction == direction)

    return {
        'j_rows': len(res.j_table.rows),
        'b_rows': len(res.b_table.rows),
        'j_txns': len(res.j_txns),
        'b_txns': len(res.b_txns),
        'j_matched': sum(1 for t in res.j_txns if t.used),
        'b_matched': sum(1 for t in res.b_txns if t.used),
        'j_status': {s: count(j_summary, s) for s in STATUS_ORDER},
        'b_status': {s: count(b_summary, s) for s in STATUS_ORDER},
        'j_in': total(res.j_txns, '收'),
        'j_out': total(res.j_txns, '支'),
        'b_in': total(res.b_txns, '收'),
        'b_out': total(res.b_txns, '支'),
        'groups': len(res.groups),
        'merged_groups': sum(1 for g in res.groups.values() if len(g) > 2),
        'fee_pairs': sum(1 for t in res.j_txns if t.match_type == '部分匹配'),
        'group_txns': sum(len(g) for g in res.groups.values() if len(g) > 2),
        'j_unmatched': sum(1 for t in res.j_txns if not t.used),
        'b_unmatched': sum(1 for t in res.b_txns if not t.used),
        'j_summary': j_summary,
        'b_summary': b_summary,
    }


def file_fingerprint(path):
    digest = hashlib.sha256()
    try:
        with open(path, 'rb') as handle:
            for chunk in iter(lambda: handle.read(1 << 20), b''):
                digest.update(chunk)
    except OSError:
        return ''
    return digest.hexdigest()[:16]


def _display(value):
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, str):
        return value.strip()
    return value


def _voucher_index_map(txns):
    """按凭证号顺序从 1 开始连续编排索引号。

    把所有出现过的凭证号去重后按数值排序，映射到 1,2,3…N；
    凭证号相同的行索引号一致（如凭证1→索引1、凭证2→索引2、…）。
    """
    vouchers = set()
    for t in txns:
        if t.voucher and str(t.voucher).strip():
            vouchers.add(str(t.voucher).strip())

    def _key(v):
        try:
            return (0, int(v))
        except (TypeError, ValueError):
            return (1, v)

    ordered = sorted(vouchers, key=_key)
    return {v: i + 1 for i, v in enumerate(ordered)}


def _write_side_by_side(wb, res):
    """新建「左右并列核对」工作表：日记账在左、银行流水在右，按匹配组逐行对齐。

    每行 = 一条日记账（左半）并排 一条银行流水（右半）；匹配组号一致的若干行构成
    一个核对单元（单笔匹配=一行，加总匹配=多行），便于一眼看出两边是否对上。
    """
    header_fill = PatternFill('solid', fgColor='305496')
    jh_fill = PatternFill('solid', fgColor='1F4E79')   # 日记账侧表头
    bh_fill = PatternFill('solid', fgColor='548235')   # 银行流水侧表头
    header_font = Font(name='微软雅黑', size=10, bold=True, color='FFFFFF')
    center = Alignment(horizontal='center', vertical='center', wrap_text=True)
    left_a = Alignment(horizontal='left', vertical='center', wrap_text=True)

    ws = wb.create_sheet('左右并列核对')
    ws.sheet_view.showGridLines = False
    # 按凭证号顺序从 1 编排索引号（凭证号一致索引号一致）
    v_index = _voucher_index_map(res.j_txns)

    headers = ['匹配组号', '匹配状态', '匹配方式', '核对差额(元)',
               '日-行号', '日-日期', '日-凭证号', '日-索引号', '日-对方', '日-摘要', '日-收入(元)', '日-支出(元)',
               '',                                            # 分隔列
               '流-行号', '流-日期', '流-凭证号(对应日账)', '流-索引号', '流-对方', '流-摘要', '流-收入(元)', '流-支出(元)',
               '日期核对', '对方户名核对', '金额核对']
    for col, text in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=text or None)
        cell.font = header_font
        if 5 <= col <= 12:
            cell.fill = jh_fill
        elif 14 <= col <= 21:
            cell.fill = bh_fill
        elif col in (22, 23, 24):
            cell.fill = header_fill
        else:
            cell.fill = header_fill
        cell.alignment = center
        if col == 13:
            ws.column_dimensions[get_column_letter(col)].width = 2
    ws.row_dimensions[1].height = 34
    ws.freeze_panes = 'A2'

    status_fill = {'已匹配': 'C6EFCE', '组匹配': 'BDD7EE', '部分匹配': 'FFEB9C',
                   '待查': 'FFC7CE', '未参与': 'EDEDED'}
    pair_fill = PatternFill('solid', fgColor='FFFFFF')

    def fill_status(cell, status):
        color = status_fill.get(status)
        if color:
            cell.fill = PatternFill('solid', fgColor=color)

    def amt(cents, direction):
        if cents is None:
            return None
        return round(cents / 100.0, 2) if direction == '收' else None

    def amt_out(cents, direction):
        if cents is None:
            return None
        return round(cents / 100.0, 2) if direction == '支' else None

    # 归并：匹配组 + 未匹配单边，生成左右并排的行
    groups = sorted(res.groups.items(), key=lambda kv: kv[0])
    j_by_row = defaultdict(list)
    b_by_row = defaultdict(list)
    for t in res.j_txns:
        j_by_row[t.row_no].append(t)
    for t in res.b_txns:
        b_by_row[t.row_no].append(t)

    j_unmatched = sorted([t for t in res.j_txns if not t.used], key=lambda t: (t.d or date.min, t.row_no))
    b_unmatched = sorted([t for t in res.b_txns if not t.used], key=lambda t: (t.d or date.min, t.row_no))

    # ---- 3 列核对判断用的候选索引（按方向+日期、方向+金额） ----
    def _cand_index(txns):
        by_day = defaultdict(list)      # (direction, date) -> [txn]
        by_amount = defaultdict(list)   # (direction, cents) -> [txn]
        for t in txns:
            by_day[(t.direction, t.d)].append(t)
            by_amount[(t.direction, t.cents)].append(t)
        return by_day, by_amount

    b_day, b_amt = _cand_index(res.b_txns)      # 流水候选（判断日记账待查）
    j_day, j_amt = _cand_index(res.j_txns)      # 日记账候选（判断流水待查）

    def _day_ok(idx_day, direction, d, window):
        """是否存在候选日期在窗口内。"""
        if d is None:
            return True
        for offset in range(-window, window + 1):
            if (direction, d + timedelta(days=offset)) in idx_day:
                return True
        return False

    def _name_ok_any(idx_day, direction, d, name, window, threshold):
        if not name:
            return True
        if d is None:
            days = [k[1] for k in idx_day if k[0] == direction]
        else:
            days = [d + timedelta(days=off) for off in range(-window, window + 1)]
        for day in days:
            for t in idx_day.get((direction, day), ()):
                if t.name and name_similarity(name, t.name) >= threshold:
                    return True
        return False

    def _amt_ok(idx_amt, idx_day, direction, d, cents, window, limit):
        """金额核对：单笔相等，或窗口内可加总相等（带预算与记忆化，避免卡顿）。"""
        if (direction, cents) in idx_amt:
            return True
        if d is None:
            return False
        pool = []
        for offset in range(-window, window + 1):
            pool.extend(idx_day.get((direction, d + timedelta(days=offset)), ()))
        if len(pool) < 2 or len(pool) > limit:
            return False
        # 金额种类裁剪 + 预算 + 记忆化：加总判断只作核对辅助，绝不因穷举卡死
        vals = sorted({t.cents for t in pool}, reverse=True)[:24]
        target = cents
        n = len(vals)
        memo = {}
        budget = [120000]

        def _can(i, rem):
            if rem == 0:
                return True
            if i >= n or rem < 0:
                return False
            if budget[0] <= 0:
                return True          # 预算耗尽：候选众多，视为很可能可加总，立即返回
            budget[0] -= 1
            key = (i, rem)
            if key in memo:
                return memo[key]
            if vals[i] > rem:
                r = _can(i + 1, rem)
            else:
                r = _can(i + 1, rem) or _can(i + 1, rem - vals[i])
            memo[key] = r
            return r

        return _can(0, target)

    def _has_name_match(txn, others, threshold):
        """单侧成员能否在另一侧找到名称对得上的伙伴。"""
        if not txn.name:
            return True
        named = [o for o in others if o.name]
        if not named:
            return True
        return any(name_similarity(txn.name, o.name) >= threshold for o in named)

    def _block_checks(j_members, b_members):
        """已匹配单元的三项真实核对：日期、户名、金额。"""
        if not j_members or not b_members:
            return ['否', '否', '否']
        window = res.options.date_window
        threshold = res.options.name_threshold
        tol = int(round(res.options.amount_tol * 100))
        d_ok = any(_day_delta(a, b) <= window for a in j_members for b in b_members)
        if len(j_members) <= len(b_members):
            n_ok = all(_has_name_match(a, b_members, threshold) for a in j_members)
        else:
            n_ok = all(_has_name_match(b, j_members, threshold) for b in b_members)
        a_ok = abs(sum(t.cents for t in j_members) - sum(t.cents for t in b_members)) <= tol
        return ['是' if d_ok else '否', '是' if n_ok else '否', '是' if a_ok else '否']

    def push_block(ws, row, j_members, b_members, gid, status, mtype, note=''):
        """把一个核对单元写成若干并排行。"""
        n = max(len(j_members), len(b_members), 1)
        j_total = sum((t.cents if t.direction == '收' else -t.cents) for t in j_members)
        b_total = sum((t.cents if t.direction == '收' else -t.cents) for t in b_members)
        diff = (j_total - b_total) / 100.0
        # 组内日记账凭证号（多笔合并，供流水侧引用）
        j_vouchers = '、'.join(dict.fromkeys(j.voucher for j in j_members if j.voucher))
        for i in range(n):
            j = j_members[i] if i < len(j_members) else None
            b = b_members[i] if i < len(b_members) else None
            # 流水侧凭证号 = 对应日记账的凭证号（组匹配时整组同一批凭证号）
            b_voucher = j.voucher if (j and not b_members) else j_vouchers
            # 索引号按凭证号顺序从 1 编排；多笔合并时取首个凭证号的索引（用首位凭证号查映射）
            j_vkey = str(j.voucher).strip() if j and j.voucher else ''
            b_vkey = str(b_voucher).strip() if b_voucher else ''
            if b_vkey and '、' in b_vkey:
                b_vkey = b_vkey.split('、')[0]
            j_index = v_index.get(j_vkey) if j_vkey else None
            b_index = v_index.get(b_vkey) if b_vkey else None
            vals = [
                gid, status, mtype,
                round(diff, 2) if i == 0 else None,
                j.row_no if j else None,
                j.d if j else None,
                j.voucher if j else None,
                j_index,
                j.raw_name if j else None,
                j.summary if j else None,
                amt(j.cents, j.direction) if j else None,
                amt_out(j.cents, j.direction) if j else None,
                None,
                b.row_no if b else None,
                b.d if b else None,
                b_voucher,
                b_index,
                b.raw_name if b else None,
                b.summary if b else None,
                amt(b.cents, b.direction) if b else None,
                amt_out(b.cents, b.direction) if b else None,
            ]
            # 3 列核对：已匹配/组匹配 -> 是；待查单边 -> 依据对方候选判断
            window = res.options.date_window
            threshold = res.options.name_threshold
            limit = res.options.group_limit
            if status == '待查':
                if j is not None:      # 日侧待查：用流水候选
                    d_ok = _day_ok(b_day, j.direction, j.d, window)
                    n_ok = _name_ok_any(b_day, j.direction, j.d, j.name, window, threshold)
                    a_ok = _amt_ok(b_amt, b_day, j.direction, j.d, j.cents, window, limit)
                else:                  # 流侧待查：用日记账候选
                    d_ok = _day_ok(j_day, b.direction, b.d, window)
                    n_ok = _name_ok_any(j_day, b.direction, b.d, b.name, window, threshold)
                    a_ok = _amt_ok(j_amt, j_day, b.direction, b.d, b.cents, window, limit)
                check_cols = ['是' if d_ok else '否', '是' if n_ok else '否', '是' if a_ok else '否']
            else:
                check_cols = _block_checks(j_members, b_members)
            vals += check_cols
            for col, v in enumerate(vals, 1):
                cell = ws.cell(row=row, column=col, value=v)
                if col == 13:
                    cell.fill = pair_fill
                if col in (1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 14, 15, 16, 17, 18, 20, 21):
                    cell.alignment = center if col in (1, 2, 3, 4, 5, 6, 7, 8, 11, 12, 14, 15, 16, 17, 20, 21) else left_a
                if col in (22, 23, 24):
                    cell.alignment = center
            fill_status(ws.cell(row=row, column=2), status)
            if status == '待查':
                # 待查单边块：整行标红，空着的流水/日记账侧也标出「待查」
                wait_fill = PatternFill('solid', fgColor='FFC7CE')
                for c in range(1, 25):
                    if c != 13:
                        ws.cell(row=row, column=c).fill = wait_fill
                if b is None:
                    hint = ws.cell(row=row, column=14, value='待查·无对应流水')
                    hint.fill = wait_fill
                    hint.alignment = center
                if j is None:
                    hint = ws.cell(row=row, column=5, value='待查·无对应日记账')
                    hint.fill = wait_fill
                    hint.alignment = center
            row += 1
        return row

    row = 2
    for gid, members in groups:
        jm = sorted([t for t in members if t.src == 'j'], key=lambda t: t.row_no)
        bm = sorted([t for t in members if t.src == 'b'], key=lambda t: t.row_no)
        is_group = len(members) > 2
        status = '组匹配' if is_group else '已匹配'
        mtype = next((t.match_type for t in members if t.match_type), '精确')
        row = push_block(ws, row, jm, bm, 'M{0:04d}'.format(gid), status, mtype)

    # 未匹配单边：一边有值、另一边为空，明显暴露
    for t in j_unmatched:
        row = push_block(ws, row, [t], [], '', '待查', '单边', t.note)
    for t in b_unmatched:
        row = push_block(ws, row, [], [t], '', '待查', '单边', t.note)

    last_row = row - 1
    for col, width in ((1, 9), (2, 9), (3, 10), (4, 12), (5, 7), (6, 11), (7, 9), (8, 9),
                       (9, 22), (10, 28), (11, 11), (12, 11),
                       (14, 7), (15, 11), (16, 13), (17, 9), (18, 22), (19, 28), (20, 11), (21, 11),
                       (22, 9), (23, 12), (24, 10)):
        ws.column_dimensions[get_column_letter(col)].width = width
    if last_row >= 2:
        ws.auto_filter.ref = 'A1:X{0}'.format(last_row)


# ---------------------------------------------------------------------------
# 待查手工核对
# ---------------------------------------------------------------------------

MANUAL_SHEET = '待查手工核对'
META_SHEET = '_对账参数'
_MANUAL_HEAD_ROW = 4
_MANUAL_FIRST_ROW = 5


def _manual_sort(txns):
    return sorted(txns, key=lambda t: (t.d or date.min, t.row_no))


def write_manual_sheet(wb, res):
    """新建「待查手工核对」：待查日记账在左、待查流水在右，两侧填相同组号即可配对。"""
    thin = Side(style='thin', color='BFBFBF')
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    header_font = Font(name='微软雅黑', size=10, bold=True, color='FFFFFF')
    bold_font = Font(name='微软雅黑', size=10, bold=True)
    center = Alignment(horizontal='center', vertical='center', wrap_text=True)
    left_a = Alignment(horizontal='left', vertical='center', wrap_text=True)
    entry_fill = PatternFill('solid', fgColor='FFF2CC')
    key_fill = PatternFill('solid', fgColor='F2F2F2')
    jh_fill = PatternFill('solid', fgColor='DDEBF7')
    bh_fill = PatternFill('solid', fgColor='E2EFDA')

    ws = wb.create_sheet(MANUAL_SHEET)
    ws.sheet_view.showGridLines = False

    j_left = _manual_sort([t for t in res.j_txns if not t.used])
    b_left = _manual_sort([t for t in res.b_txns if not t.used])

    title = ws.cell(row=1, column=1, value='待查手工核对（左右填相同组号即可配对，一笔对多笔也行）')
    title.font = Font(name='微软雅黑', size=14, bold=True, color='1F3864')
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=16)

    tip = ('用法：① 在左右两侧黄色的「手工组号」列，给要配对的行填同一个数字（1、2、3…），多笔对一笔就填同一个号；'
           '② 保存本文件；③ 回到工具点「导入手工核对」，新结果里这些行会以「手工」方式出现在「左右并列核对」页；'
           '④ 行号列只用来定位，请不要改动；想撤回就清空组号。')
    tip_cell = ws.cell(row=2, column=1, value=tip)
    tip_cell.font = Font(name='微软雅黑', size=9, color='C00000')
    tip_cell.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=16)
    ws.row_dimensions[2].height = 46

    lh = ws.cell(row=3, column=1, value='日记账待查（{0} 笔）'.format(len(j_left)))
    lh.font = bold_font
    lh.fill = jh_fill
    lh.alignment = center
    ws.merge_cells(start_row=3, start_column=1, end_row=3, end_column=8)
    rh = ws.cell(row=3, column=10, value='银行流水待查（{0} 笔）'.format(len(b_left)))
    rh.font = bold_font
    rh.fill = bh_fill
    rh.alignment = center
    ws.merge_cells(start_row=3, start_column=10, end_row=3, end_column=16)

    headers = ['手工组号', '日-行号', '日-日期', '日-凭证号', '日-对方户名', '日-摘要', '日-收入', '日-支出',
               '', '手工组号', '流-行号', '流-日期', '流-对方户名', '流-摘要', '流-收入', '流-支出']
    for col, text in enumerate(headers, 1):
        cell = ws.cell(row=_MANUAL_HEAD_ROW, column=col, value=text or None)
        cell.font = header_font
        cell.alignment = center
        cell.border = border
        if col in (1, 10):
            cell.fill = PatternFill('solid', fgColor='C00000')
        elif col < 9:
            cell.fill = PatternFill('solid', fgColor='2F5597')
        elif col > 10:
            cell.fill = PatternFill('solid', fgColor='375623')

    count = max(len(j_left), len(b_left))
    for i in range(count):
        row = _MANUAL_FIRST_ROW + i
        j = j_left[i] if i < len(j_left) else None
        b = b_left[i] if i < len(b_left) else None
        values = [
            None,
            j.row_no if j else None,
            j.d if j else None,
            j.voucher if j else None,
            j.raw_name if j else None,
            j.summary if j else None,
            round(j.cents / 100.0, 2) if j and j.direction == '收' else None,
            round(j.cents / 100.0, 2) if j and j.direction == '支' else None,
            None,
            None,
            b.row_no if b else None,
            b.d if b else None,
            b.raw_name if b else None,
            b.summary if b else None,
            round(b.cents / 100.0, 2) if b and b.direction == '收' else None,
            round(b.cents / 100.0, 2) if b and b.direction == '支' else None,
        ]
        for col, value in enumerate(values, 1):
            cell = ws.cell(row=row, column=col, value=value)
            cell.border = border
            if col in (1, 10):
                cell.fill = entry_fill
                cell.alignment = center
            elif col in (2, 11):
                cell.fill = key_fill
                cell.alignment = center
            elif col in (3, 4, 7, 8, 12, 15, 16):
                cell.alignment = center
            else:
                cell.alignment = left_a
        for col in (7, 8, 15, 16):
            ws.cell(row=row, column=col).number_format = '#,##0.00'
        for col in (3, 12):
            ws.cell(row=row, column=col).number_format = 'yyyy-mm-dd'

    widths = {1: 10, 2: 8, 3: 11, 4: 9, 5: 26, 6: 30, 7: 12, 8: 12,
              9: 2, 10: 10, 11: 8, 12: 11, 13: 26, 14: 30, 15: 12, 16: 12}
    for col, width in widths.items():
        ws.column_dimensions[get_column_letter(col)].width = width
    ws.row_dimensions[_MANUAL_HEAD_ROW].height = 26
    ws.freeze_panes = 'A{0}'.format(_MANUAL_FIRST_ROW)

    if count:
        last = _MANUAL_FIRST_ROW + count - 1
        for col in ('A', 'J'):
            ws.conditional_formatting.add(
                '{0}{1}:{0}{2}'.format(col, _MANUAL_FIRST_ROW, last),
                FormulaRule(formula=['LEN(TRIM({0}{1}))>0'.format(col, _MANUAL_FIRST_ROW)],
                            fill=PatternFill('solid', fgColor='FFD966'), stopIfTrue=True))
    else:
        ws.cell(row=_MANUAL_FIRST_ROW, column=1,
                value='本次没有待查记录，两边全部对上，不需要手工核对。')
    return ws


def _manual_gid(value):
    """把用户填的组号统一成 int / 字符串两种可比形式。"""
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value) if value.is_integer() else None
    text = str(value).strip()
    if not text:
        return None
    try:
        number = float(text)
        if number.is_integer():
            return int(number)
    except (TypeError, ValueError):
        pass
    return text


def _manual_rowno(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return int(number) if number.is_integer() else None


def write_meta_sheet(wb, res):
    """隐藏的参数页：记录源文件指纹，手工核对回读时用来确认是同一对源文件。"""
    ws = wb.create_sheet(META_SHEET)
    rows = [
        ('工具版本', VERSION),
        ('导出时间', datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
        ('日记账文件', getattr(res.j_table, 'path', '')),
        ('日记账指纹', res.j_fp),
        ('银行流水文件', getattr(res.b_table, 'path', '')),
        ('银行流水指纹', res.b_fp),
        ('日期容差', res.options.date_window),
        ('金额容差', res.options.amount_tol),
        ('名称相似度', res.options.name_threshold),
        ('组匹配上限', res.options.group_limit),
    ]
    for key, value in rows:
        ws.append([key, value])
    ws.column_dimensions['A'].width = 16
    ws.column_dimensions['B'].width = 90
    ws.sheet_state = 'hidden'
    return ws


def read_manual_pairs(path):
    """读回「待查手工核对」页填的组号。

    返回 ({组号: {'j': [...], 'b': [...]}}, 警告列表, 参数页信息)。
    """
    if IMPORT_ERROR is not None:
        raise UserError('缺少 openpyxl 依赖：{0}'.format(IMPORT_ERROR))
    try:
        wb = load_workbook(path, data_only=True, read_only=True)
    except Exception as exc:
        raise UserError('打不开手工核对文件：{0}'.format(exc))
    try:
        if MANUAL_SHEET not in wb.sheetnames:
            raise UserError('这个文件里没有「待查手工核对」工作表。\n请选择本工具导出的结果文件，并在那一页填组号。')
        ws = wb[MANUAL_SHEET]
        rows = list(ws.iter_rows(values_only=True))
        meta = {}
        if META_SHEET in wb.sheetnames:
            for row in wb[META_SHEET].iter_rows(values_only=True):
                if row and row[0] is not None:
                    meta[str(row[0]).strip()] = row[1] if len(row) > 1 else None
    finally:
        wb.close()

    head_index = None
    for index, row in enumerate(rows[:12]):
        texts = [str(v).strip() if v is not None else '' for v in row]
        if '日-行号' in texts and '流-行号' in texts:
            head_index = index
            break
    if head_index is None:
        raise UserError('「待查手工核对」页的表头认不出来，可能被改动过。\n请重新导出结果后再填。')

    head = [str(v).strip() if v is not None else '' for v in rows[head_index]]
    j_row_col = head.index('日-行号')
    b_row_col = head.index('流-行号')
    gid_cols = [i for i, text in enumerate(head) if text == '手工组号']
    if len(gid_cols) < 2:
        raise UserError('「待查手工核对」页找不到左右两个「手工组号」列，可能被改动过。')
    j_gid_col = min(gid_cols)
    b_gid_col = max(gid_cols)

    def cell(row, col):
        return row[col] if col < len(row) else None

    def put(bucket, gid, side, row_no):
        if not gid or not row_no:
            return
        item = bucket.setdefault(gid, {'j': [], 'b': []})
        if row_no not in item[side]:
            item[side].append(row_no)

    bucket = {}
    for row in rows[head_index + 1:]:
        put(bucket, _manual_gid(cell(row, j_gid_col)), 'j', _manual_rowno(cell(row, j_row_col)))
        put(bucket, _manual_gid(cell(row, b_gid_col)), 'b', _manual_rowno(cell(row, b_row_col)))

    pairs, warnings = {}, []
    for gid, item in bucket.items():
        if not item['j'] or not item['b']:
            side = '日记账' if item['j'] else '银行流水'
            warnings.append('手工组号 {0} 只在{1}一侧填了，另一侧没有同号，已忽略。'.format(gid, side))
            continue
        pairs[gid] = item
    return pairs, warnings, meta


def apply_manual_pairs(res, pairs):
    """把手填的组号落成匹配结果，返回 (成功组数, 被跳过的说明)。"""
    j_by_row = defaultdict(list)
    for t in res.j_txns:
        j_by_row[t.row_no].append(t)
    b_by_row = defaultdict(list)
    for t in res.b_txns:
        b_by_row[t.row_no].append(t)

    next_gid = (max(res.groups) if res.groups else 0) + 1
    applied, skipped = 0, []
    for gid in sorted(pairs, key=lambda key: str(key)):
        item = pairs[gid]
        jm = [t for row in item['j'] for t in j_by_row.get(row, [])]
        bm = [t for row in item['b'] for t in b_by_row.get(row, [])]
        if not jm or not bm:
            skipped.append('手工组号 {0}：填的行号在源表里找不到，已跳过。'.format(gid))
            continue
        busy = [t for t in jm + bm if t.used]
        if busy:
            skipped.append('手工组号 {0}：有的行已经自动匹配过（行号 {1}），请只填「待查」的行。'.format(
                gid, '、'.join(str(t.row_no) for t in busy)))
            continue
        group = list(jm) + list(bm)
        for t in group:
            t.used = True
            t.match_id = next_gid
            t.match_type = '手工'
            t.note = '手工核对确认'
        res.groups[next_gid] = group
        next_gid += 1
        applied += 1
    return applied, skipped


def manual_reconcile(journal_path, bank_path, manual_path, output_path,
                     options=None, progress=None, cancel=None):
    """重新对账并应用手工核对结果，最后把完整结果写到 output_path。"""
    started = time.time()
    res = reconcile(journal_path, bank_path, options, progress=progress, cancel=cancel)
    if progress:
        progress('读回手工核对…', 72)
    pairs, warnings, meta = read_manual_pairs(manual_path)
    mismatch = []
    if meta.get('日记账指纹') and meta['日记账指纹'] != res.j_fp:
        mismatch.append('日记账')
    if meta.get('银行流水指纹') and meta['银行流水指纹'] != res.b_fp:
        mismatch.append('银行流水')
    if mismatch:
        raise UserError(
            '这个手工核对文件生成时用的{0}和现在选的不一样，行号对不上，为避免错配已停止。\n'
            '请在「左右并列核对」里核对一下是不是同一套账，然后用当前这两个文件重新对账，'
            '在新的结果文件的「待查手工核对」页里填组号。'.format('、'.join(mismatch)))
    if not pairs:
        raise UserError('没有读到有效的手工组号。\n'
                        '请在「待查手工核对」页左右两侧给要配对的行填同一个组号（1、2、3…），保存后再导入。')
    applied, skipped = apply_manual_pairs(res, pairs)
    if not applied:
        raise UserError('手工组号都没能应用：\n' + '\n'.join(skipped[:10]))
    res.warnings.extend(warnings)
    res.warnings.extend(skipped)
    res.elapsed = time.time() - started
    if progress:
        progress('生成结果…', 76)
    export_result(res, output_path, progress=progress)
    return res, applied


def export_result(res, output_path, progress=None):
    """生成结果工作簿。"""
    if IMPORT_ERROR is not None:
        raise UserError('缺少 openpyxl 依赖：{0}'.format(IMPORT_ERROR))

    header_fill = PatternFill('solid', fgColor='305496')
    header_font = Font(name='微软雅黑', size=10, bold=True, color='FFFFFF')
    label_font = Font(name='微软雅黑', size=10, bold=True)
    title_font = Font(name='微软雅黑', size=14, bold=True, color='1F3864')
    center = Alignment(horizontal='center', vertical='center', wrap_text=True)
    fill_ok = PatternFill('solid', fgColor='C6EFCE')
    fill_group = PatternFill('solid', fgColor='BDD7EE')
    fill_part = PatternFill('solid', fgColor='FFEB9C')
    fill_bad = PatternFill('solid', fgColor='FFC7CE')
    fill_skip = PatternFill('solid', fgColor='EDEDED')

    wb = Workbook()
    wb.remove(wb.active)

    # 按凭证号顺序从 1 编排索引号（凭证号一致索引号一致），全工作簿共用
    v_index = _voucher_index_map(res.j_txns)

    def write_header(ws, headers):
        for col, text in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=text)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = center
        ws.row_dimensions[1].height = 26
        ws.freeze_panes = 'A2'

    def autofit(ws, headers, sample):
        for col, text in enumerate(headers, 1):
            width = min(36, max(9, len(str(text)) * 2 + 2))
            for row in sample[:50]:
                if col - 1 < len(row) and row[col - 1] is not None:
                    width = max(width, min(36, len(str(row[col - 1])) * 1.7 + 2))
            ws.column_dimensions[get_column_letter(col)].width = width

    def status_rules(ws, last_col, last_row, status_col):
        rng = 'A2:{0}{1}'.format(get_column_letter(last_col), last_row)
        rules = (('已匹配', fill_ok), ('组匹配', fill_group), ('部分匹配', fill_part),
                 ('待查', fill_bad), ('未参与', fill_skip))
        letter = get_column_letter(status_col)
        for text, fill in rules:
            ws.conditional_formatting.add(
                rng, FormulaRule(formula=['${0}2="{1}"'.format(letter, text)],
                                 fill=fill, stopIfTrue=True))

    def detail_sheet(title, table, src):
        ws = wb.create_sheet(title)
        src_txns = res.j_txns if src == 'j' else res.b_txns
        # 每个原始行号 -> 该行解析出的 Txn（取第一个）
        txn_by_row = {}
        for t in src_txns:
            txn_by_row.setdefault(t.row_no, t)
        # 匹配组 -> 组内日记账凭证号（供流水侧引用）
        group_j_voucher = {}
        for gid, members in res.groups.items():
            vs = '、'.join(dict.fromkeys(t.voucher for t in members if t.src == 'j' and t.voucher))
            if vs:
                group_j_voucher[gid] = vs
        match_id_of_row = {}
        for t in src_txns:
            if t.used and t.match_id:
                match_id_of_row[t.row_no] = t.match_id

        def _suffix(name, exist):
            return '{0}(重排)'.format(name) if name in exist else name

        base_headers = list(table.headers)
        if src == 'j':
            add_headers = [_suffix('凭证号', base_headers), _suffix('索引号', base_headers)]
        else:
            add_headers = [_suffix('凭证号', base_headers),
                           _suffix('索引号', base_headers),
                           _suffix('对应日记账凭证号', base_headers)]
        headers = base_headers + add_headers + ['匹配组号', '匹配状态', '匹配方式', '关联笔数', '匹配金额', '差额', '说明']
        write_header(ws, headers)
        row_map = build_row_summary(res, src)
        status_col = len(base_headers) + len(add_headers) + 1
        sample = []
        last_row = 1
        for row_no, row in table.rows:
            values = [_display(row[i]) if i < len(row) else None for i in range(len(table.headers))]
            t = txn_by_row.get(row_no)
            voucher = t.voucher if t else ''
            if src == 'b':
                gid = match_id_of_row.get(row_no)
                corr_voucher = group_j_voucher.get(gid, '') if gid else ''
                corr_index = v_index.get(str(corr_voucher).strip()) if corr_voucher else ''
                # 流水本身无凭证号；索引号=对应日记账凭证号编排的索引
                values += [voucher, corr_index, corr_voucher]
            else:
                # 日记账：索引号=凭证号编排的索引（凭证号一致索引号一致）
                index_no = v_index.get(str(voucher).strip()) if voucher else ''
                values += [voucher, index_no]
            info = row_map.get(row_no, ('未参与', '', '', 0, 0, '', 0))
            if info[4] == '':
                info = (info[0], info[1], info[2], info[3], 0, info[5], info[6])
            status, gid, mtype, count, matched_cents, note, diff = info
            values += [gid, status, mtype, count,
                       round(matched_cents / 100.0, 2), round(diff / 100.0, 2), note]
            ws.append(values)
            last_row += 1
            if len(sample) < 50:
                sample.append(values)

        autofit(ws, headers, sample)
        status_rules(ws, len(headers), last_row, status_col)
        ws.auto_filter.ref = 'A1:{0}{1}'.format(get_column_letter(len(headers)), last_row)
        return ws

    # ---- sheet 1：左右并列核对（日记账在左、银行流水在右） ----
    _write_side_by_side(wb, res)
    if progress:
        progress('正在写「左右并列核对」…', 74)

    # ---- sheet 2：待查手工核对（没对上的左右排列，手工填组号） ----
    write_manual_sheet(wb, res)
    if progress:
        progress('正在写「待查手工核对」…', 76)

    # ---- sheet 2 / 3：两侧逐行核对 ----
    detail_sheet('日记账核对', res.j_table, 'j')
    if progress:
        progress('正在写「日记账核对」…', 78)
    detail_sheet('流水核对', res.b_table, 'b')
    if progress:
        progress('正在写「流水核对」…', 82)

    # ---- sheet 3：未匹配清单 ----
    ws = wb.create_sheet('未匹配清单')
    headers = ['来源', '行号', '日期', '方向', '金额', '凭证号', '索引号', '对方', '摘要', '可能原因']
    write_header(ws, headers)
    leftovers = [(t, '日记账') for t in res.j_txns if not t.used] + \
                [(t, '流水') for t in res.b_txns if not t.used]
    leftovers.sort(key=lambda pair: (pair[1], pair[0].d or date.min, pair[0].row_no))
    sample = []
    for txn, side in leftovers:
        voucher = txn.voucher
        index_no = v_index.get(str(voucher).strip()) if voucher else ''
        values = [side, txn.row_no, txn.d, txn.direction,
                  round(txn.cents / 100.0, 2), voucher, index_no,
                  txn.raw_name, txn.summary, txn.note]
        ws.append(values)
        if len(sample) < 50:
            sample.append(values)
    autofit(ws, headers, sample)
    if leftovers:
        ws.auto_filter.ref = 'A1:J{0}'.format(len(leftovers) + 1)

    # ---- sheet 4：组匹配明细 ----
    multi = [(gid, members) for gid, members in sorted(res.groups.items()) if len(members) > 2]
    if multi:
        ws = wb.create_sheet('组匹配明细')
        headers = ['匹配组号', '来源', '行号', '日期', '方向', '金额', '对方']
        write_header(ws, headers)
        sample = []
        for gid, members in multi:
            for txn in sorted(members, key=lambda t: (t.src, t.row_no)):
                values = ['M{0:04d}'.format(gid), '日记账' if txn.src == 'j' else '流水',
                          txn.row_no, txn.d, txn.direction,
                          round(txn.cents / 100.0, 2), txn.raw_name]
                ws.append(values)
                if len(sample) < 50:
                    sample.append(values)
        autofit(ws, headers, sample)

    # ---- sheet 5：汇总 ----
    if progress:
        progress('正在写「对账汇总」…', 88)
    ws = wb.create_sheet('对账汇总')
    ws.column_dimensions['A'].width = 24
    ws.column_dimensions['B'].width = 96
    stats = compute_stats(res)
    jtab, btab = res.j_table, res.b_table

    def size_text(path):
        try:
            return '{0:.1f} KB'.format(os.path.getsize(path) / 1024.0)
        except OSError:
            return ''

    def col_text(table):
        m = table.colmap
        parts = [table.headers[i] for i in (m['date'], m['name'], m['summary']) if i >= 0]
        if m['mode'] == 'two':
            parts += [table.headers[i] for i in (m['inflow'], m['outflow']) if i >= 0]
        elif m['mode'] == 'signed':
            parts += [table.headers[i] for i in (m['amount'], m['receiver'], m['payer']) if i >= 0]
        else:
            parts += [table.headers[i] for i in (m['amount'], m['flag']) if i >= 0]
        return '、'.join(dict.fromkeys(parts))

    def pct(value, base):
        return '{0:.1%}'.format(value / base) if base else '—'

    diag = res.diagnosis or {}

    lines = [
        (APP_NAME + ' 对账汇总', ''),
        ('工具版本', VERSION),
        ('生成时间', datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
        ('耗时', '{0:.1f} 秒'.format(res.elapsed)),
        ('', ''),
        ('【输入文件】', ''),
        ('日记账', os.path.basename(jtab.path)),
        ('  路径', jtab.path),
        ('  工作表 / 大小', '{0} / {1}'.format(jtab.sheet, size_text(jtab.path))),
        ('  文件指纹', res.j_fp),
        ('  识别列', col_text(jtab)),
        ('银行流水', os.path.basename(btab.path)),
        ('  路径', btab.path),
        ('  工作表 / 大小', '{0} / {1}'.format(btab.sheet, size_text(btab.path))),
        ('  文件指纹', res.b_fp),
        ('  识别列', col_text(btab)),
        ('', ''),
        ('【匹配参数】', ''),
        ('日期容差', '{0} 天'.format(res.options.date_window)),
        ('金额容差', '{0:.2f} 元'.format(res.options.amount_tol)),
        ('名称相似度阈值', '{0:.2f}'.format(res.options.name_threshold)),
        ('组匹配上限', '{0} 笔'.format(res.options.group_limit)),
        ('小额差额容差', '±{0:,.2f} 元（且不超过金额的 {1:.1%}，差几元以上要求户名高度相似）'.format(
            getattr(res.options, 'fee_cap', 0) / 100.0, getattr(res.options, 'fee_ratio', 0.0))),
        ('', ''),
        ('【日记账】', ''),
        ('原始行数 / 有效笔数', '{0} / {1}'.format(stats['j_rows'], stats['j_txns'])),
        ('收入（笔 / 金额）', '{0} 笔 / {1:,.2f}'.format(sum(1 for t in res.j_txns if t.direction == '收'), stats['j_in'] / 100.0)),
        ('支出（笔 / 金额）', '{0} 笔 / {1:,.2f}'.format(sum(1 for t in res.j_txns if t.direction == '支'), stats['j_out'] / 100.0)),
        ('已匹配 / 匹配率', '{0} 笔 / {1}'.format(stats['j_matched'], pct(stats['j_matched'], stats['j_txns']))),
        ('未匹配', '{0} 笔'.format(stats['j_unmatched'])),
        ('行状态分布', '已匹配 {0}、组匹配 {1}、部分匹配 {2}、待查 {3}、未参与 {4}'.format(
            stats['j_status']['已匹配'], stats['j_status']['组匹配'], stats['j_status']['部分匹配'],
            stats['j_status']['待查'], stats['j_status']['未参与'])),
        ('', ''),
        ('【银行流水】', ''),
        ('原始行数 / 有效笔数', '{0} / {1}'.format(stats['b_rows'], stats['b_txns'])),
        ('收入（笔 / 金额）', '{0} 笔 / {1:,.2f}'.format(sum(1 for t in res.b_txns if t.direction == '收'), stats['b_in'] / 100.0)),
        ('支出（笔 / 金额）', '{0} 笔 / {1:,.2f}'.format(sum(1 for t in res.b_txns if t.direction == '支'), stats['b_out'] / 100.0)),
        ('已匹配 / 匹配率', '{0} 笔 / {1}'.format(stats['b_matched'], pct(stats['b_matched'], stats['b_txns']))),
        ('未匹配', '{0} 笔'.format(stats['b_unmatched'])),
        ('行状态分布', '已匹配 {0}、组匹配 {1}、部分匹配 {2}、待查 {3}、未参与 {4}'.format(
            stats['b_status']['已匹配'], stats['b_status']['组匹配'], stats['b_status']['部分匹配'],
            stats['b_status']['待查'], stats['b_status']['未参与'])),
        ('', ''),
        ('【匹配结果】', ''),
        ('匹配组数', '{0}（其中多笔合并 {1} 组）'.format(stats['groups'], stats['merged_groups'])),
        ('组匹配涉及笔数', '{0}'.format(stats['group_txns'])),
        ('小额差额配对', '{0} 笔（手续费/净额到账，建议复核）'.format(stats['fee_pairs'])),
        ('手工核对配对', '{0} 组'.format(sum(1 for g in res.groups.values()
                                            if any(t.match_type == '手工' for t in g)))),
        ('收入差额（日记账 - 流水）', '{0:,.2f}'.format((stats['j_in'] - stats['b_in']) / 100.0)),
        ('支出差额（日记账 - 流水）', '{0:,.2f}'.format((stats['j_out'] - stats['b_out']) / 100.0)),
        ('', ''),
        ('【提示】', ''),
    ]
    if diag:
        rows = [
            ('', ''),
            ('【匹配前体检】', ''),
            ('日记账笔数', '{0}'.format(diag.get('总笔数', 0))),
            ('金额能对上', '{0} 笔（{1}）'.format(
                diag.get('金额能对上', 0),
                pct(diag.get('金额能对上', 0), diag.get('总笔数', 0)))),
            ('  其中日期也对得上', '{0} 笔'.format(diag.get('日期能对上', 0))),
            ('  其中户名也对得上', '{0} 笔（{1}）'.format(
                diag.get('户名能对上', 0),
                pct(diag.get('户名能对上', 0), max(1, diag.get('日期能对上', 0))))),
            ('收付方向', '已自动对调（流水方向与日记账相反）'
             if diag.get('方向自动对调') else '正常'),
            ('实际日期容差', '{0} 天'.format(diag.get('日期容差', res.options.date_window))),
            ('户名判据', '硬性要求一致' if diag.get('严格户名', True)
             else '已放宽：户名不符的凭金额+日期配对，方式列标「金额匹配」'),
            ('同金额多笔', '{0} 组'.format(diag.get('同金额多笔', 0))),
            ('日记账 / 流水笔数', '{0} / {1} 笔（日记账多 {2} 笔）'.format(
                diag.get('日记账笔数', 0), diag.get('流水笔数', 0), diag.get('笔数差', 0))),
            ('疑似内部划转', '{0} 组 / {1:,.2f} 元'.format(
                diag.get('疑似内部划转组数', 0), diag.get('疑似内部划转金额', 0.0))),
        ]
        pos = next((i for i, row in enumerate(lines) if row[0] == '【日记账】'), len(lines))
        lines[pos:pos] = rows
    for warning in res.warnings[:20]:
        lines.append(('警告', warning))
    if len(res.warnings) > 20:
        lines.append(('警告', '还有 {0} 条警告，详见日志'.format(len(res.warnings) - 20)))
    if not res.warnings:
        lines.append(('状态', '无'))
    if stats['j_unmatched'] or stats['b_unmatched']:
        lines.append(('手工核对', '还有日记账 {0} 笔、流水 {1} 笔没对上：可在「待查手工核对」页给两边填同一个组号，'
                                '保存后用「导入手工核对」重新出结果。'.format(
                                    stats['j_unmatched'], stats['b_unmatched'])))

    for index, (key, value) in enumerate(lines, 1):
        left = ws.cell(row=index, column=1, value=key)
        right = ws.cell(row=index, column=2, value=value)
        if index == 1:
            left.font = title_font
        elif key.endswith('】') or not key:
            pass
        else:
            left.font = label_font
        right.alignment = Alignment(vertical='center', wrap_text=(key == '警告'))

    for row in ws.iter_rows(min_row=2, max_col=2):
        if row[0].value in ('【输入文件】', '【匹配参数】', '【匹配前体检】', '【日记账】',
                            '【银行流水】', '【匹配结果】', '【提示】'):
            row[0].font = Font(name='微软雅黑', size=10, bold=True, color='C00000')

    write_meta_sheet(wb, res)

    if progress:
        progress('正在保存…', 92)
    try:
        wb.save(output_path)
    except PermissionError:
        raise UserError('结果文件正被占用（可能已经在 Excel 里打开），请关闭后重试，或换个文件名。')
    except Exception as exc:
        raise UserError('保存结果失败：{0}'.format(exc))


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------

@dataclass
class Options:
    date_window: int = 1
    group_window: int = 3        # 合并匹配允许的跨天数（拆笔到账常见跨几天）
    amount_tol: float = 0.0
    name_threshold: float = 0.85
    group_limit: int = MAX_GROUP
    pool_cap: int = 300          # 单笔合并匹配的候选上限，超过就留给手工核对
    group_budget: int = 60000    # 单笔合并匹配的搜索节点预算
    group_seconds: float = 45.0  # 合并匹配整层的时间上限（秒）
    fallback_unique: bool = True  # 名称不符但双向唯一时是否仍标「唯一候选」
    name_strict: bool = True     # 户名是否作为硬判据（配不上时会自动放宽并标记）
    fee_cap: int = 20000         # 小额差额配对的封顶（分，200 元），0 表示关闭本层
    fee_ratio: float = 0.002     # 小额差额占金额的比例上限
    fee_days: int = 2            # 小额差额允许的跨天数


def reconcile(journal_path, bank_path, options=None, progress=None, cancel=None):
    """完整对账流程：读表 -> 匹配 -> 返回结果（不负责写文件）。"""
    started = time.time()
    opts = options or Options()

    def report(message, percent=None):
        logging.info(message)
        if progress:
            progress(message, percent)
        if cancel is not None and cancel.is_set():
            raise UserError('已取消')

    report('读取日记账…', 5)
    if os.path.abspath(journal_path) == os.path.abspath(bank_path):
        raise UserError('两个文件选成了同一个，请分别选择日记账和银行流水。')
    j_table = prepare_table(journal_path, 'journal')

    report('读取银行流水…', 15)
    b_table = prepare_table(bank_path, 'bank')

    report('解析金额与日期…', 25)
    j_txns, j_ignored, j_warnings = build_txns(j_table, 'j')
    j_names = set(t.name for t in j_txns if t.name)
    b_txns, b_ignored, b_warnings = build_txns(b_table, 'b', j_names)
    ignored = {}
    ignored.update(j_ignored)
    ignored.update(b_ignored)
    warnings = list(j_table.warnings) + list(b_table.warnings) + j_warnings + b_warnings

    if not j_txns:
        raise UserError('日记账没有解析出任何一笔有效金额。\n请检查金额列是否被识别错，或金额是否存成了文本。')
    if not b_txns:
        raise UserError('银行流水没有解析出任何一笔有效金额。\n请检查金额列是否被识别错，或金额是否存成了文本。')

    for label, total_rows, bad in (('日记账', len(j_table.rows), len(j_ignored)),
                                   ('银行流水', len(b_table.rows), len(b_ignored))):
        if total_rows and bad / float(total_rows) > 0.2:
            warnings.append('{0}：有 {1}/{2} 行金额为空或无法识别，请确认是否选对了金额列。'.format(
                label, bad, total_rows))

    if progress:
        progress('匹配前体检…', 30)
    opts, diagnosis = auto_tune(j_txns, b_txns, opts, warnings)
    report('体检：金额能对上 {0}/{1} 笔，日期能对上 {2} 笔，户名能对上 {3} 笔'.format(
        diagnosis['金额能对上'], diagnosis['总笔数'],
        diagnosis['日期能对上'], diagnosis['户名能对上']), 32)
    if progress:
        progress('开始匹配…', 33)
    groups = match_all(j_txns, b_txns, opts, report, cancel)

    report('标注未匹配原因…', 70)
    explain_unmatched(j_txns, b_txns, opts)

    result = Result(j_table=j_table, b_table=b_table, j_txns=j_txns, b_txns=b_txns,
                    groups=groups, ignored=ignored, warnings=warnings, options=opts,
                    elapsed=time.time() - started,
                    j_fp=file_fingerprint(journal_path),
                    b_fp=file_fingerprint(bank_path),
                    diagnosis=diagnosis)
    return result


def setup_logging():
    log_dir = os.path.join(BASE_DIR, 'logs')
    try:
        os.makedirs(log_dir, exist_ok=True)
        path = os.path.join(log_dir, 'recon_{0}.log'.format(date.today().strftime('%Y%m%d')))
        handlers = [logging.FileHandler(path, encoding='utf-8')]
    except OSError:
        return None

    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s %(levelname)s %(message)s',
                        handlers=handlers, force=True)
    # 清理过期日志
    try:
        limit = time.time() - LOG_KEEP_DAYS * 86400
        for name in os.listdir(log_dir):
            full = os.path.join(log_dir, name)
            if name.endswith('.log') and os.path.isfile(full) and os.path.getmtime(full) < limit:
                os.remove(full)
    except OSError:
        pass
    return path


def _format_duration(seconds):
    if seconds < 60:
        return '{0:.1f} 秒'.format(seconds)
    return '{0} 分 {1:.0f} 秒'.format(int(seconds // 60), seconds % 60)


# ---------------------------------------------------------------------------
# 界面
# ---------------------------------------------------------------------------

def run_gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    class App:
        def __init__(self, root):
            self.root = root
            self.journal_path = ''
            self.bank_path = ''
            self.queue = queue.Queue()
            self.cancel_event = threading.Event()
            self.busy = False
            self.last_output = ''

            root.title('{0}  v{1}'.format(APP_NAME, VERSION))
            root.geometry('720x520')
            root.minsize(660, 480)

            style = ttk.Style()
            try:
                style.theme_use('vista')
            except tk.TclError:
                pass

            title = tk.Label(root, text=APP_NAME, font=('微软雅黑', 16, 'bold'), fg='#1F3864')
            title.pack(anchor='w', padx=18, pady=(14, 0))
            subtitle = tk.Label(root, text='本地离线运行 · 只读源文件 · 不上传任何数据',
                                font=('微软雅黑', 9), fg='#7F7F7F')
            subtitle.pack(anchor='w', padx=18, pady=(2, 10))

            files = tk.LabelFrame(root, text=' 选择文件 ', font=('微软雅黑', 9), padx=10, pady=8)
            files.pack(fill='x', padx=18)

            self.lbl_journal = self._file_row(files, 0, '日记账', '选择日记账…', self.pick_journal)
            self.lbl_bank = self._file_row(files, 1, '银行流水', '选择流水…', self.pick_bank)

            settings = tk.LabelFrame(root, text=' 匹配设置 ', font=('微软雅黑', 9), padx=10, pady=8)
            settings.pack(fill='x', padx=18, pady=(10, 0))

            self.var_window = tk.StringVar(value='1 天')
            self.var_tol = tk.StringVar(value='0.00 元')
            self.var_threshold = tk.StringVar(value='0.85')
            self.var_group = tk.StringVar(value='30 笔')

            self._combo(settings, 0, '日期容差', self.var_window,
                        ['0 天', '1 天', '3 天', '7 天'])
            self._combo(settings, 1, '金额容差', self.var_tol,
                        ['0.00 元', '0.01 元', '0.05 元', '0.10 元'])
            self._combo(settings, 2, '名称相似度', self.var_threshold,
                        ['0.70', '0.80', '0.85', '0.90', '1.00'])
            self._combo(settings, 3, '组匹配上限', self.var_group,
                        ['5 笔', '10 笔', '20 笔', '30 笔', '50 笔', '100 笔'])

            hint = tk.Label(settings, text='日期容差指跨天入账；名称相似度越低越宽松；组匹配上限指一笔日记账最多合并几笔流水（或反之）。',
                            font=('微软雅黑', 8), fg='#7F7F7F')
            hint.grid(row=1, column=0, columnspan=8, sticky='w', pady=(6, 0))

            actions = tk.Frame(root)
            actions.pack(fill='x', padx=18, pady=(14, 0))
            self.btn_start = tk.Button(actions, text='开始对账', command=self.start,
                                       font=('微软雅黑', 11, 'bold'), bg='#2E75B6', fg='white',
                                       activebackground='#1F4E79', activeforeground='white',
                                       relief='flat', padx=26, pady=6, cursor='hand2')
            self.btn_start.pack(side='left')
            self.btn_cancel = tk.Button(actions, text='取消', command=self.cancel, state='disabled',
                                        font=('微软雅黑', 10), padx=16, pady=6)
            self.btn_cancel.pack(side='left', padx=8)
            self.btn_manual = tk.Button(actions, text='导入手工核对', command=self.import_manual,
                                        font=('微软雅黑', 10), padx=14, pady=6, cursor='hand2')
            self.btn_manual.pack(side='left')
            self.btn_open = tk.Button(actions, text='打开结果文件夹', command=self.open_output,
                                      font=('微软雅黑', 10), padx=14, pady=6, cursor='hand2',
                                      state='disabled')
            self.btn_open.pack(side='left', padx=(8, 0))
            self.lbl_status = tk.Label(actions, text='请选择两个 Excel 文件', font=('微软雅黑', 9), fg='#404040')
            self.lbl_status.pack(side='left', padx=10)

            self.bar = ttk.Progressbar(root, orient='horizontal', mode='determinate', maximum=100)
            self.bar.pack(fill='x', padx=18, pady=(12, 4))

            footer = tk.Label(root, text='日志：logs/ 目录    结果另存为新文件，不会改动原始表格',
                              font=('微软雅黑', 8), fg='#7F7F7F')
            footer.pack(anchor='w', padx=18, pady=(2, 10))

            root.protocol('WM_DELETE_WINDOW', self.on_close)

        def _file_row(self, parent, row, label, button_text, command):
            tk.Label(parent, text=label, font=('微软雅黑', 10), width=7, anchor='e').grid(
                row=row, column=0, sticky='e', pady=4)
            value = tk.Label(parent, text='未选择', font=('微软雅黑', 9), fg='#C00000',
                             anchor='w', relief='groove', bg='#FAFAFA', padx=8)
            value.grid(row=row, column=1, sticky='we', padx=8, pady=4)
            tk.Button(parent, text=button_text, command=command, font=('微软雅黑', 9),
                      padx=10, cursor='hand2').grid(row=row, column=2, pady=4)
            parent.grid_columnconfigure(1, weight=1)
            return value

        def _combo(self, parent, column, label, variable, values):
            tk.Label(parent, text=label, font=('微软雅黑', 9)).grid(row=0, column=column * 2,
                                                                    sticky='w', padx=(0, 4))
            box = ttk.Combobox(parent, textvariable=variable, values=values, width=8,
                               state='readonly', font=('微软雅黑', 9))
            box.grid(row=0, column=column * 2 + 1, sticky='w', padx=(0, 18))

        @staticmethod
        def _shorten(path):
            name = os.path.basename(path)
            if len(name) <= 46:
                return name
            return name[:22] + '…' + name[-20:]

        def _set_path(self, which, path):
            if which == 'j':
                self.journal_path = path
                label = self.lbl_journal
            else:
                self.bank_path = path
                label = self.lbl_bank
            label.config(text=self._shorten(path), fg='#1F3864')
            logging.info('选择文件 %s: %s', which, path)

        def pick_journal(self):
            path = filedialog.askopenfilename(title='选择日记账 Excel',
                                              filetypes=[('Excel 文件', '*.xlsx *.xlsm')])
            if path:
                self._set_path('j', path)

        def pick_bank(self):
            path = filedialog.askopenfilename(title='选择银行流水 Excel',
                                              filetypes=[('Excel 文件', '*.xlsx *.xlsm')])
            if path:
                self._set_path('b', path)

        def _options(self):
            window = int(self.var_window.get().split()[0])
            tol = float(self.var_tol.get().split()[0])
            threshold = float(self.var_threshold.get())
            group = int(self.var_group.get().split()[0])
            return Options(date_window=window, amount_tol=tol,
                           name_threshold=threshold, group_limit=group)

        def _set_busy(self, busy):
            self.busy = busy
            state = 'disabled' if busy else 'normal'
            self.btn_start.config(state=state)
            self.btn_manual.config(state=state)
            self.btn_cancel.config(state='normal' if busy else 'disabled')

        def _out_dir(self):
            """默认把结果存到日记账所在文件夹，省得保存到看不见的地方。"""
            for path in (self.journal_path, self.bank_path):
                if path:
                    folder = os.path.dirname(os.path.abspath(path))
                    if os.path.isdir(folder):
                        return folder
            return os.path.expanduser('~')

        def open_output(self):
            """打开结果文件所在文件夹。"""
            path = self.last_output
            if not path:
                messagebox.showinfo('还没有结果', '请先完成一次对账。')
                return
            folder = os.path.dirname(os.path.abspath(path))
            if not os.path.isdir(folder):
                messagebox.showwarning('文件夹不存在', '结果文件夹已不存在：\n' + folder)
                return
            try:
                os.startfile(folder)  # noqa: 仅 Windows
            except AttributeError:
                messagebox.showinfo('结果位置', folder)
            except OSError as exc:
                messagebox.showwarning('打不开文件夹', str(exc))

        def start(self):
            if self.busy:
                return
            if not self.journal_path or not self.bank_path:
                messagebox.showwarning('还差文件', '请先选择「日记账」和「银行流水」两个 Excel 文件。')
                return
            default_name = '对账结果_{0}.xlsx'.format(datetime.now().strftime('%Y%m%d_%H%M'))
            output = filedialog.asksaveasfilename(title='保存对账结果', defaultextension='.xlsx',
                                                  initialfile=default_name,
                                                  initialdir=self._out_dir(),
                                                  filetypes=[('Excel 文件', '*.xlsx')])
            if not output:
                return

            self.last_output = output
            self.btn_open.config(state='normal')
            self.cancel_event.clear()
            self._set_busy(True)
            self.bar['value'] = 2
            self.lbl_status.config(text='准备中…')
            options = self._options()
            logging.info('开始对账 journal=%s bank=%s options=%s', self.journal_path, self.bank_path, options)
            thread = threading.Thread(target=self._worker, args=(output, options), daemon=True)
            thread.start()

        def import_manual(self):
            """读回在「待查手工核对」页填好组号的结果文件，重新生成最终结果。"""
            if self.busy:
                return
            if not self.journal_path or not self.bank_path:
                messagebox.showwarning('还差文件', '请先选择「日记账」和「银行流水」两个 Excel 文件。')
                return
            manual = filedialog.askopenfilename(
                title='选择填好组号的结果文件',
                initialdir=self._out_dir(),
                filetypes=[('Excel 文件', '*.xlsx *.xlsm')])
            if not manual:
                return
            default_name = '对账结果_手工核对_{0}.xlsx'.format(datetime.now().strftime('%Y%m%d_%H%M'))
            output = filedialog.asksaveasfilename(title='保存手工核对后的结果', defaultextension='.xlsx',
                                                  initialfile=default_name,
                                                  initialdir=os.path.dirname(os.path.abspath(manual)),
                                                  filetypes=[('Excel 文件', '*.xlsx')])
            if not output:
                return

            self.last_output = output
            self.btn_open.config(state='normal')
            self.cancel_event.clear()
            self._set_busy(True)
            self.bar['value'] = 2
            self.lbl_status.config(text='正在读手工核对…')
            options = self._options()
            logging.info('导入手工核对 manual=%s output=%s', manual, output)
            thread = threading.Thread(target=self._manual_worker,
                                      args=(manual, output, options), daemon=True)
            thread.start()

        def _manual_worker(self, manual, output, options):
            try:
                def progress(message, percent=None):
                    self.queue.put(('message', message))
                    if percent is not None:
                        self.queue.put(('percent', percent))

                result, applied = manual_reconcile(self.journal_path, self.bank_path, manual, output,
                                                   options, progress=progress, cancel=self.cancel_event)
                if self.cancel_event.is_set():
                    raise UserError('已取消')
                logging.info('手工核对已应用 %s 组', applied)
                self.queue.put(('done', (result, output)))
            except UserError as exc:
                self.queue.put(('failed', ('提示', str(exc))))
            except Exception as exc:
                logging.error('手工核对失败：%s\n%s', exc, traceback.format_exc())
                self.queue.put(('failed', ('出错了',
                                           '{0}\n\n详细信息已写入 logs 目录的日志文件。'.format(exc))))

        def cancel(self):
            self.cancel_event.set()
            self.lbl_status.config(text='正在取消…')

        def _worker(self, output, options):
            try:
                def progress(message, percent=None):
                    self.queue.put(('message', message))
                    if percent is not None:
                        self.queue.put(('percent', percent))

                result = reconcile(self.journal_path, self.bank_path, options,
                                   progress=progress, cancel=self.cancel_event)
                if self.cancel_event.is_set():
                    raise UserError('已取消')
                export_result(result, output, progress=progress)
                self.queue.put(('done', (result, output)))
            except UserError as exc:
                self.queue.put(('failed', ('提示', str(exc))))
            except Exception as exc:
                logging.error('对账失败：%s\n%s', exc, traceback.format_exc())
                self.queue.put(('failed', ('出错了',
                                           '{0}\n\n详细信息已写入 logs 目录的日志文件。'.format(exc))))

        def _poll(self):
            try:
                while True:
                    kind, payload = self.queue.get_nowait()
                    if kind == 'message':
                        self.lbl_status.config(text=payload)
                    elif kind == 'percent':
                        self.bar['value'] = payload
                    elif kind == 'done':
                        self._finish(*payload)
                    elif kind == 'failed':
                        self._fail(*payload)
            except queue.Empty:
                pass
            self.root.after(80, self._poll)

        def _finish(self, result, output):
            self._set_busy(False)
            self.bar['value'] = 100
            stats = compute_stats(result)
            self.lbl_status.config(text='完成，用时 {0}'.format(_format_duration(result.elapsed)))

            lines = [
                '日记账 {0} 行 / 流水 {1} 行'.format(stats['j_rows'], stats['b_rows']),
                '日记账已匹配 {0}/{1} 笔，流水已匹配 {2}/{3} 笔'.format(
                    stats['j_matched'], stats['j_txns'], stats['b_matched'], stats['b_txns']),
                '未匹配：日记账 {0} 笔，流水 {1} 笔'.format(stats['j_unmatched'], stats['b_unmatched']),
            ]
            diag = result.diagnosis or {}
            if diag:
                total_j = diag.get('总笔数') or 1
                lines.append('')
                lines.append('配对体检：日记账 {0} 笔中，金额能对上 {1} 笔（{2:.0%}），'
                             '其中日期也对得上 {3} 笔、户名也对得上 {4} 笔'.format(
                                 total_j, diag.get('金额能对上', 0),
                                 diag.get('金额能对上', 0) / float(total_j),
                                 diag.get('日期能对上', 0), diag.get('户名能对上', 0)))
                if diag.get('笔数差'):
                    lines.append('注意：日记账比流水多 {0} 笔，这部分不可能全部配上。'.format(
                        diag['笔数差']))
                if diag.get('疑似内部划转组数'):
                    lines.append('日记账里有 {0} 组「同额一收一支」，很像内部划转（合计 {1:,.2f} 元），'
                                 '不会出现在本账户流水里。'.format(
                                     diag['疑似内部划转组数'], diag.get('疑似内部划转金额', 0.0)))
            if stats['merged_groups']:
                lines.append('其中一笔对多笔（拆分/合并到账）{0} 组'.format(stats['merged_groups']))
            if stats['fee_pairs']:
                lines.append('其中小额差额配对 {0} 笔（手续费/净额到账，建议复核）'.format(stats['fee_pairs']))
            manual_groups = sum(1 for g in result.groups.values()
                                if any(t.match_type == '手工' for t in g))
            if manual_groups:
                lines.append('其中手工核对配对 {0} 组'.format(manual_groups))
            if abs(stats['j_in'] - stats['b_in']) > 0 or abs(stats['j_out'] - stats['b_out']) > 0:
                lines.append('两边收入合计差 {0:,.2f} 元、支出合计差 {1:,.2f} 元（未达账项会造成差异，属正常）'.format(
                    (stats['j_in'] - stats['b_in']) / 100.0, (stats['j_out'] - stats['b_out']) / 100.0))
            if result.warnings:
                lines.append('')
                lines.append('有 {0} 条提示，建议看一下「对账汇总」页：'.format(len(result.warnings)))
                lines.extend('· ' + w for w in result.warnings[:3])

            text = '\n'.join(lines) + '\n\n结果已保存：\n' + output + '\n\n是否现在打开？'
            if messagebox.askyesno('对账完成', text):
                try:
                    os.startfile(output)  # noqa: 仅 Windows
                except AttributeError:
                    pass
                except OSError as exc:
                    messagebox.showwarning('打不开文件', str(exc))

        def _fail(self, title, message):
            self._set_busy(False)
            self.bar['value'] = 0
            self.lbl_status.config(text='没有完成')
            if title == '提示':
                messagebox.showwarning('无法继续', message)
            else:
                messagebox.showerror(title, message)

        def on_close(self):
            if self.busy:
                if not messagebox.askyesno('正在对账', '对账还没结束，确定要退出吗？'):
                    return
                self.cancel_event.set()
            self.root.destroy()

    root = tk.Tk()
    app = App(root)
    root.after(80, app._poll)
    root.mainloop()


def main():
    setup_logging()
    logging.info('%s v%s 启动，Python %s', APP_NAME, VERSION, sys.version.split()[0])

    if IMPORT_ERROR is not None:
        message = ('缺少 openpyxl 依赖：{0}\n\n'
                   '请确认 pylibs 文件夹与本程序在同一个目录。').format(IMPORT_ERROR)
        try:
            import tkinter as tk
            from tkinter import messagebox
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror('无法启动', message)
            root.destroy()
        except Exception:
            print(message)
        return 1

    if sys.version_info < (3, 8):
        print('需要 Python 3.8 或更高版本，当前是 {0}'.format(sys.version.split()[0]))
        return 1

    try:
        run_gui()
    except Exception as exc:
        logging.error('界面异常：%s\n%s', exc, traceback.format_exc())
        try:
            import tkinter as tk
            from tkinter import messagebox
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror('程序出错', '{0}\n\n详见 logs 目录日志。'.format(exc))
            root.destroy()
        except Exception:
            print('程序出错：{0}'.format(exc))
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
