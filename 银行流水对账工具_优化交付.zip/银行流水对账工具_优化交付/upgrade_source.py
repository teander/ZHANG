"""将保留的 v2.2.2 原始源码升级；交付时无需运行本脚本。"""
from pathlib import Path
import ast

ROOT = Path(__file__).resolve().parent
target = ROOT / '银行流水对账工具' / '银行流水对账工具.py'
source = (ROOT / '原始源码备份' / '银行流水对账工具.py').read_text(encoding='utf-8-sig')


def replace_function(name, code):
    global source
    tree = ast.parse(source)
    node = next(n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name == name)
    lines = source.splitlines(keepends=True)
    source = ''.join(lines[:node.lineno - 1]) + code.strip() + '\n' + ''.join(lines[node.end_lineno:])


source = source.replace("VERSION = '2.2.2'", "VERSION = '2.3.0'")
source = source.replace('银行流水自动对账工具 v2.2.1', '银行流水自动对账工具 v2.3.0')
source = source.replace("AMOUNT_C = ('交易金额', '发生额', '金额', '交易额')", "AMOUNT_C = ('交易金额', '原币金额', '发生额', '金额', '交易额')")
source = source.replace("        mapping['receiver'] = -1\n        mapping['payer'] = -1\n", '')
source = source.replace("if mapping['flag'] < 0:", "if mapping['flag'] < 0 and 'flag_pair' not in mapping:")
source = source.replace("        problem = _validate_mapping(mapping, headers, label)\n        if problem:\n            last_problem = problem\n            continue\n\n", '')
source = source.replace("        refine_note = refine_mapping(table, src)\n", "        refine_note = refine_mapping(table, src)\n        problem = _validate_mapping(mapping, headers, label)\n        if problem:\n            last_problem = problem\n            continue\n")
source = source.replace("if a in b or b in a:", "if min(len(a), len(b)) >= 4 and (a in b or b in a):")
source = source.replace("    acc_a = set(re.findall", "    if min(len(a), len(b)) <= 3:\n        return 0.0\n    acc_a = set(re.findall", 1)
source = source.replace("return int(round(value * 100))", "return parse_amount(Decimal(str(value)))", 1)
source = source.replace("    if isinstance(value, Decimal):\n        return int((value * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))", "    if isinstance(value, Decimal):\n        if not value.is_finite():\n            return None\n        try:\n            return int((value * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))\n        except (InvalidOperation, OverflowError, ValueError):\n            return None")
source = source.replace("    cents = int((number * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))", "    cents = parse_amount(number)\n    if cents is None:\n        return None", 1)

replace_function('refine_mapping', '''
def refine_mapping(table, src):
    """借贷金额优先；每行空/零金额可回退到原币金额与 J/D 标记。"""
    m = table.colmap
    if m['mode'] == 'two':
        amount = _find_amount_column(table, (m['inflow'], m['outflow']))
        if amount >= 0:
            m['fallback_amount'] = amount
    else:
        if m.get('flag', -1) < 0:
            m['flag'] = _find_flag_column(table, (m.get('amount', -1),))
    # J/D 既可能是金额列也可能是 0/1、勾号；此处仅记录位置，逐行判读。
    left = next((i for i, h in enumerate(table.headers) if clean_header(h) in _PAIR_LEFT), -1)
    right = next((i for i, h in enumerate(table.headers) if clean_header(h) in _PAIR_RIGHT), -1)
    if left >= 0 and right >= 0:
        m['flag_pair'] = (left, right)
    return '已启用逐行金额回退与 J/D 标志检查' if m.get('fallback_amount', -1) >= 0 else ''
''')

replace_function('direction_from_flag', '''
def direction_from_flag(value, src):
    """收/付是现金方向；只有借/贷才随日记账与银行视角转换。"""
    if value is None:
        return None
    s = to_halfwidth(value).strip().lower()
    if s in ('收', '收入', '进', '进账', '存入', '收款', '+', '1', '1.0'):
        return '收'
    if s in ('付', '支', '支出', '出', '付出', '支取', '付款', '-', '-1', '2', '2.0'):
        return '支'
    if s in ('j', '借', '借方', '借记', 'dr', 'debit'):
        return '收' if src in ('j', 'journal') else '支'
    if s in ('d', '贷', '贷方', '贷记', 'c', 'cr', 'credit'):
        return '支' if src in ('j', 'journal') else '收'
    return None
''')

replace_function('_signed_direction_hint', '''
def _signed_direction_hint(table, exclude_names=None):
    """只接受覆盖大多数有效行且明显领先的本方户名，避免频繁对手被误认。"""
    mapping = table.colmap
    counts = defaultdict(int)
    total, negative = 0, False
    for _row_no, row in table.rows:
        cents = parse_amount(_get(row, mapping.get('amount', -1)))
        if not cents or parse_date(_get(row, mapping['date'])) is None:
            continue
        total += 1
        negative = negative or cents < 0
        names = {normalize_name(_get(row, mapping.get(k, -1))) for k in ('payer', 'receiver')}
        for name in names - {''}:
            counts[name] += 1
    excluded = set(exclude_names or ())
    candidates = sorted(((count, name) for name, count in counts.items() if name not in excluded), reverse=True)
    if not candidates or not total:
        return '', negative
    count, name = candidates[0]
    runner_up = candidates[1][0] if len(candidates) > 1 else 0
    if count / total < 0.8 or count <= runner_up:
        return '', negative
    return name, negative
''')

# These helpers belong alongside parsing, before build_txns.
replace_function('build_txns', '''
def _active_marker(value):
    if value is None:
        return False
    s = to_halfwidth(value).strip().lower()
    return s not in ('', '0', '0.0', '-', '--', '否', 'false', 'n', 'no', '×', '✗')


def _row_flag(table, row, src):
    m = table.colmap
    direction = direction_from_flag(_get(row, m.get('flag', -1)), src)
    if direction:
        return direction
    if 'flag_pair' in m:
        left, right = m['flag_pair']
        a, b = _active_marker(_get(row, left)), _active_marker(_get(row, right))
        if a != b:
            header = clean_header(table.headers[left if a else right])
            if header in ('j', '借', '借方', 'dr', 'debit'):
                return direction_from_flag('借', src)
            if header in ('d', '贷', '贷方', 'cr', 'credit'):
                return direction_from_flag('贷', src)
            return '收' if a else '支'
    return None


def _balance_directions(table):
    """以相邻余额差=本笔金额验证方向；同日顺序不明时比较正反排列。"""
    m = table.colmap
    if m.get('balance', -1) < 0:
        return {}
    records = []
    for row_no, row in table.rows:
        day = parse_date(_get(row, m['date']))
        balance_raw = _get(row, m['balance'])
        bal = parse_amount(balance_raw) if _cell_has_value(balance_raw) else None
        amt = parse_amount(_get(row, m.get('amount', -1)))
        raw_day = _get(row, m['date'])
        timestamp = str(raw_day) if isinstance(raw_day, datetime) or ':' in str(raw_day) else ''
        if day is not None:
            records.append((day, timestamp, row_no, bal, amt))
    possibilities = []
    for reverse_rows in (False, True):
        ordered = sorted(records, key=lambda r: (r[0], r[1], -r[2] if reverse_rows else r[2]))
        found = {}
        for previous, current in zip(ordered, ordered[1:]):
            if previous[3] is None or current[3] is None or not current[4]:
                continue
            delta = current[3] - previous[3]
            if abs(delta) == abs(current[4]):
                found[current[2]] = '收' if delta > 0 else '支'
        possibilities.append(found)
    a, b = possibilities
    if len(a) > len(b):
        return a
    if len(b) > len(a):
        return b
    return {row: direction for row, direction in a.items() if b.get(row) == direction}


def build_txns(table, src, counterparty_names=None):
    """严格逐行解析；方向不明或冲突的记录保留在未参与清单并说明原因。"""
    txns, ignored, warnings = [], {}, []
    m = table.colmap
    own, has_negative = ('', False)
    balances = {}
    if m['mode'] == 'signed':
        own, has_negative = _signed_direction_hint(table, counterparty_names)
        balances = _balance_directions(table)
        if own:
            warnings.append('{0}：识别本方户名「{1}」，按付款人/收款人位置确定对方。'.format(table.label, own))
        if balances:
            warnings.append('{0}：有 {1} 行通过相邻交易后余额差验证方向。'.format(table.label, len(balances)))
    elif m['mode'] == 'single':
        has_negative = any((parse_amount(_get(r, m.get('amount', -1))) or 0) < 0 for _n, r in table.rows)
    for row_no, row in table.rows:
        if not _row_has_value(row):
            continue
        day = parse_date(_get(row, m['date']))
        if day is None:
            ignored[(src, row_no)] = '日期无法识别或为合计/标题行，未自动匹配'
            continue
        name_raw = _get(row, m.get('name', -1))
        pairs = []
        bad = False
        if m['mode'] == 'two':
            for key, direction in (('inflow', '收'), ('outflow', '支')):
                value = _get(row, m.get(key, -1))
                amount = parse_amount(value)
                if amount is None and _cell_has_value(value):
                    bad = True
                elif amount:
                    pairs.append((_flip(direction) if amount < 0 else direction, abs(amount)))
            if bad:
                ignored[(src, row_no)] = '借贷金额含无法识别的值，未自动匹配'
                continue
            if not pairs and m.get('fallback_amount', -1) >= 0:
                amount = parse_amount(_get(row, m['fallback_amount']))
                direction = _row_flag(table, row, src)
                if amount and direction:
                    pairs.append((_flip(direction) if amount < 0 else direction, abs(amount)))
                elif amount:
                    ignored[(src, row_no)] = '原币金额存在，但 J/D 标志缺失或同时有效，收付方向不明'
                    continue
        else:
            amount = parse_amount(_get(row, m.get('amount', -1)))
            if amount is None:
                ignored[(src, row_no)] = '金额无法识别'
                continue
            if not amount:
                ignored[(src, row_no)] = '金额为空或为 0'
                continue
            flag = _row_flag(table, row, src)
            if m['mode'] == 'signed':
                payer = normalize_name(_get(row, m.get('payer', -1)))
                receiver = normalize_name(_get(row, m.get('receiver', -1)))
                identity = None
                if own and payer == own and receiver != own:
                    identity = '支'
                elif own and receiver == own and payer != own:
                    identity = '收'
                signed = '支' if amount < 0 else ('收' if has_negative else None)
                # 明确标志和签名金额先判；余额与本方户名作交叉校验。
                evidence = [x for x in (flag, signed, balances.get(row_no), identity) if x]
                if not evidence or len(set(evidence)) > 1:
                    ignored[(src, row_no)] = '收付方向不明或标志/余额/本方户名证据冲突，请手工核对'
                    continue
                direction = evidence[0]
                name_raw = _get(row, m.get('payer' if direction == '收' else 'receiver', -1))
            else:
                direction = flag
                if direction:
                    raw_flag = clean_header(_get(row, m.get('flag', -1)))
                    loan_flag = raw_flag in ('j', 'd', '借', '贷', '借方', '贷方', '借记', '贷记', 'dr', 'cr')
                    if amount < 0 and src in ('j', 'journal') and loan_flag:
                        direction = _flip(direction)
                else:
                    # 单金额无标志只允许存在负数时采用正负号。
                    if amount < 0 or has_negative:
                        direction = '收' if amount > 0 else '支'
                if direction is None:
                    ignored[(src, row_no)] = '单列正金额没有有效收付标志，方向不明'
                    continue
            pairs.append((direction, abs(amount)))
        if not pairs:
            ignored[(src, row_no)] = '金额为空或为 0'
            continue
        def text(key):
            value = _get(row, m.get(key, -1))
            return '' if value is None else str(value).strip()
        for direction, amount in pairs:
            party = name_raw
            if not normalize_name(party) and m['mode'] == 'two':
                party = _get(row, m.get('payer' if direction == '收' else 'receiver', -1))
            txns.append(Txn(src, row_no, direction, amount, day, normalize_name(party),
                            '' if party is None else str(party).strip(), text('summary'),
                            text('voucher'), text('index')))
    return txns, ignored, warnings
''')

replace_function('_day_delta', '''
def _day_delta(j, b):
    """无效日期不具备自动匹配证据。"""
    return abs((b.d - j.d).days) if j.d is not None and b.d is not None else 10**9
''')

replace_function('_assign_pairs', '''
def _assign_pairs(jlist, blist, opts, tol_cents=0):
    """兼容旧接口；使用最大流最小费用求整体最优一对一分配。"""
    from matching_core import assign_pairs
    return assign_pairs(jlist, blist, opts, name_similarity, tol_cents)
''')

replace_function('match_all', '''
def match_all(jtx, btx, opts, report=None, cancel=None):
    """精确单笔 → 精确合并 → 跨日唯一 → 容差 → 小额差额候选。"""
    from matching_core import match_transactions
    return match_transactions(jtx, btx, opts, name_similarity, report, cancel, UserError)
''')

# A poor profile is diagnostic evidence, never permission to disregard counterparties.
start = source.index('    if total and base[\'amount\'] < 0.2 * total:', source.index('def auto_tune('))
end = source.index('    # 户名靠不住时', start)
source = source[:start] + '''    # 收付必须由源表证据决定，不因另一份账的金额分布而整体反转。
    facts['严格户名'] = True
    ratio = base['name'] / float(base['date']) if base['date'] else 0
    facts['户名能对上率'] = ratio
    if base['date'] >= 20 and ratio < 0.5:
        warnings.append('同金额日期记录的户名大面积不符，保留户名约束，请检查本方户名及字段映射。')

''' + source[end:]
source = source.replace("name_strict: bool = True     # 户名是否作为硬判据（配不上时会自动放宽并标记）", "name_strict: bool = True     # 保留兼容字段；新版始终要求有名双方户名达标\n    extended_window: int = 7     # 高相似户名、同金额、双向唯一的跨日补配窗口")
source = source.replace("        if j.used:\n            continue\n        if not _has_time():", "        if j.used or j.note:\n            continue\n        if not _has_time():")
source = source.replace("        if b.used:\n            continue\n        if not _has_time():", "        if b.used or b.note:\n            continue\n        if not _has_time():")
source = source.replace("elif any(b.d is not None and j.d is not None and abs((b.d - j.d).days) <= window", "elif any(b.d is not None and j.d is not None and abs((b.d - j.d).days) > window")
source = source.replace("elif any(j.d is not None and b.d is not None and abs((j.d - b.d).days) <= window", "elif any(j.d is not None and b.d is not None and abs((j.d - b.d).days) > window")

# Group differences are computed once from both complete sides, not a row minus an entire group.
source = source.replace("            diff = own_cents - partner_cents", """            diff = sum(
                sum(t.cents if t.src == src else -t.cents for t in res.groups[gid])
                for gid in gids)
            if len(matched) < len(lst):
                diff += sum(t.cents for t in lst if not t.used)""")
source = source.replace("        note = ''\n        if status != '已匹配':", "        note = next((t.note for t in matched if t.note), '')\n        if status != '已匹配' and not note:")
source = source.replace("        d_ok = any(_day_delta(a, b) <= window for a in j_members for b in b_members)", """        types = {t.match_type for t in j_members + b_members}
        if types & {'组匹配', '多对多汇总'}:
            window = max(window, res.options.group_window)
        if '跨日匹配' in types:
            window = max(window, res.options.extended_window)
        d_ok = all(any(_day_delta(a, b) <= window for b in b_members) for a in j_members) and all(
            any(_day_delta(a, b) <= window for a in j_members) for b in b_members)""")
source = source.replace("            n_ok = all(_has_name_match(a, b_members, threshold) for a in j_members)", "            n_ok = all(_has_name_match(a, b_members, threshold) for a in j_members) and all(_has_name_match(b, j_members, threshold) for b in b_members)")
source = source.replace("            n_ok = all(_has_name_match(b, j_members, threshold) for b in b_members)", "            n_ok = all(_has_name_match(a, b_members, threshold) for a in j_members) and all(_has_name_match(b, j_members, threshold) for b in b_members)")
source = source.replace("    group_limit: int = MAX_GROUP", "    group_limit: int = MAX_GROUP")
source = source.replace("    group_limit: int = MAX_GROUP", "    pair_edge_cap: int = 60000   # 单个金额桶/容差层候选边上限\n    pair_seconds: float = 10.0   # 单次最优分配时间上限\n    group_limit: int = MAX_GROUP")

source = source.replace("            status = '组匹配' if gsize > 2 else '已匹配'", "            status = ('部分匹配' if any(t.match_type == '部分匹配' for t in matched) else\n                      '组匹配' if gsize > 2 else '已匹配')")
source = source.replace("        status = '组匹配' if is_group else '已匹配'", "        status = ('部分匹配' if any(t.match_type == '部分匹配' for t in members) else\n                  '组匹配' if is_group else '已匹配')")
source = source.replace("        'j_matched': sum(1 for t in res.j_txns if t.used),", """        'j_matched': sum(1 for t in res.j_txns if t.used),
        'j_confirmed': sum(1 for t in res.j_txns if t.used and t.match_type in ('精确', '名称匹配', '组匹配', '手工')),
        'j_review': sum(1 for t in res.j_txns if t.used and t.match_type not in ('精确', '名称匹配', '组匹配', '手工')),
        'b_confirmed': sum(1 for t in res.b_txns if t.used and t.match_type in ('精确', '名称匹配', '组匹配', '手工')),
        'b_review': sum(1 for t in res.b_txns if t.used and t.match_type not in ('精确', '名称匹配', '组匹配', '手工')),""")
source = source.replace("        ('已匹配 / 匹配率', '{0} 笔 / {1}'.format(stats['j_matched'], pct(stats['j_matched'], stats['j_txns']))),", """        ('已关联 / 覆盖率（含待复核）', '{0} 笔 / {1}'.format(stats['j_matched'], pct(stats['j_matched'], stats['j_txns']))),
        ('精确核对及手工确认 / 比例', '{0} 笔 / {1}'.format(stats['j_confirmed'], pct(stats['j_confirmed'], stats['j_txns']))),
        ('已关联但需复核', '{0} 笔'.format(stats['j_review'])),
        ('未参与（请同时检查，覆盖率分母为有效笔数）', '{0} 行'.format(stats['j_status']['未参与'])),""")
source = source.replace("        ('已匹配 / 匹配率', '{0} 笔 / {1}'.format(stats['b_matched'], pct(stats['b_matched'], stats['b_txns']))),", """        ('已关联 / 覆盖率（含待复核）', '{0} 笔 / {1}'.format(stats['b_matched'], pct(stats['b_matched'], stats['b_txns']))),
        ('精确核对及手工确认 / 比例', '{0} 笔 / {1}'.format(stats['b_confirmed'], pct(stats['b_confirmed'], stats['b_txns']))),
        ('已关联但需复核', '{0} 笔'.format(stats['b_review'])),
        ('未参与（请同时检查，覆盖率分母为有效笔数）', '{0} 行'.format(stats['b_status']['未参与'])),""")
source = source.replace("        ('金额容差', '{0:.2f} 元'.format(res.options.amount_tol)),", "        ('跨日唯一候选窗口', '{0} 天（高相似户名且金额双向唯一）'.format(res.options.extended_window)),\n        ('金额容差', '{0:.2f} 元'.format(res.options.amount_tol)),")
source = source.replace("            ('收付方向', '已自动对调（流水方向与日记账相反）'\n             if diag.get('方向自动对调') else '正常'),", "            ('收付方向', '按原始标志、金额符号、本方户名及余额证据解析；不按匹配率整体翻转'),")
source = source.replace("('小额差额容差', '±{0:,.2f} 元（且不超过金额的 {1:.1%}，差几元以上要求户名高度相似）'", "('小额差额容差', '上限 {0:,.2f} 元且不超过两侧较小金额的 {1:.1%}（最小1分），要求高相似户名及双向最优唯一'")

replace_function('_profile_pass', '''
def _profile_pass(jtx, btx, window, threshold, flip=False):
    """诊断只计候选覆盖，不把候选数量解释为已完成匹配。"""
    index = defaultdict(list)
    for b in btx:
        if b.d is not None:
            index[(_flip(b.direction) if flip else b.direction, b.cents)].append(b)
    facts = {'total': len(jtx), 'amount': 0, 'date': 0, 'name': 0, 'deltas': [], 'strong_deltas': []}
    for j in jtx:
        cands = index.get((j.direction, j.cents), [])
        if not cands:
            continue
        facts['amount'] += 1
        nearest = min(_day_delta(j, b) for b in cands)
        facts['deltas'].append(nearest)
        dated = [b for b in cands if _day_delta(j, b) <= window]
        facts['date'] += bool(dated)
        named = [b for b in cands if j.name and b.name and name_similarity(j.name, b.name) >= threshold]
        if named:
            facts['strong_deltas'].append(min(_day_delta(j, b) for b in named))
        facts['name'] += any(b in dated for b in named)
    return facts
''')

replace_function('auto_tune', '''
def auto_tune(jtx, btx, opts, warnings):
    """保留诊断接口；匹配率不触发整体翻转、放弃户名或任意扩大日期范围。"""
    tuned = replace(opts, name_strict=True)
    base = _profile_pass(jtx, btx, opts.date_window, opts.name_threshold)
    same = defaultdict(int)
    for j in jtx:
        same[(j.direction, j.cents)] += 1
    ratio = base['name'] / float(base['date']) if base['date'] else 0
    if base['date'] >= 20 and ratio < 0.5:
        warnings.append('金额日期相同的记录中户名大面积不符，保留户名约束，请检查字段与本方户名。')
    pairs, total = _internal_transfer_pairs(jtx)
    return tuned, {
        '总笔数': len(jtx), '金额能对上': base['amount'], '日期能对上': base['date'],
        '户名能对上': base['name'], '方向自动对调': False, '日期容差': opts.date_window,
        '严格户名': True, '户名能对上率': ratio, '同金额多笔': sum(v > 1 for v in same.values()),
        '日记账笔数': len(jtx), '流水笔数': len(btx), '笔数差': max(0, len(jtx) - len(btx)),
        '疑似内部划转组数': pairs, '疑似内部划转金额': total / 100,
    }
''')

# The header is user-facing documentation, so remove obsolete claims about automatic loosening.
doc_end = source.index('from __future__ import annotations')
source = '''# -*- coding: utf-8 -*-
"""
银行流水自动对账工具 v2.3.0

本地离线、只读原表；支持截图中的日记账及付款人/收款人流水字段。
逐行回退原币金额与 J/D，交叉验证方向；证据不足的行标记未参与。
匹配顺序：精确单笔最优分配、唯一组合加总、多对多整组汇总、跨日双向唯一、容差及差额候选。
户名不符不强配，不因覆盖率低整体翻转方向；所有候选保留复核说明。
覆盖率包含已关联待复核记录，结果另列精确核对/手工确认比例及未参与行数。
运行：双击「双击运行对账工具.bat」；详见交付目录中的修改说明.md。
"""
''' + source[doc_end:]

ast.parse(source)
target.write_text(source, encoding='utf-8')
print('Updated:', target)
