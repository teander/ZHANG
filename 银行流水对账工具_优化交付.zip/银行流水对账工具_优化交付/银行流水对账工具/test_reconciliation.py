"""离线回归测试；金额、对应行均为人工设定的模拟数据。"""
import importlib.util
import sys
import tempfile
import unittest
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('recon_app', ROOT / '银行流水对账工具.py')
app = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = app
spec.loader.exec_module(app)

JHEAD = ['日期', '凭证号', '摘要', '对方户名', '原币金额', 'J', 'D', '借方金额', '贷方金额']
BHEAD = ['付款人名称', '收款人名称', '交易日期', '交易金额', '交易后余额', '摘要']
DAY = date(2026, 10, 1)


def txn(src, row, amount, name='甲方科技有限公司', day=0, summary='', direction='收'):
    return app.Txn(src, row, direction, amount, None if day is None else DAY + timedelta(days=day),
                   name, name, summary)


def table(headers, rows, src):
    t = app.Table('', 'Sheet1', src, list(headers), [(i + 2, r) for i, r in enumerate(rows)],
                  app.map_columns(headers, src))
    app.refine_mapping(t, src)
    return t


def match(j, b, **kwargs):
    return app.match_all(j, b, app.Options(**kwargs))


class ParsingTests(unittest.TestCase):
    def test_journal_cash_flags_are_not_debit_credit_flags(self):
        self.assertEqual(app.direction_from_flag('收', 'j'), '收')
        self.assertEqual(app.direction_from_flag('付', 'j'), '支')
        self.assertEqual(app.direction_from_flag('J', 'j'), '收')
        self.assertEqual(app.direction_from_flag('D', 'b'), '收')

    def test_zero_placeholder_columns_use_original_amount(self):
        t = table(JHEAD, [[DAY, '1', '', '甲方', 100, '√', '', 0, 0],
                         [DAY, '2', '', '乙方', 200, '', '√', 0, 0]], 'journal')
        tx, _, _ = app.build_txns(t, 'j')
        self.assertEqual([(x.direction, x.cents) for x in tx], [('收', 10000), ('支', 20000)])

    def test_mixed_rows_use_fallback_only_on_empty_amount_rows(self):
        t = table(JHEAD, [[DAY, '1', '', '甲方', 100, '√', '', 100, 0],
                         [DAY, '2', '', '乙方', 200, '', '√', 0, 200],
                         [DAY, '3', '', '丙方', 300, '', '√', 0, 0]], 'journal')
        tx, _, _ = app.build_txns(t, 'j')
        self.assertEqual([(x.direction, x.cents) for x in tx], [('收', 10000), ('支', 20000), ('支', 30000)])

    def test_zero_j_d_is_not_an_active_marker(self):
        t = table(JHEAD, [[DAY, '1', '', '甲方', 100, 0, 1, 0, 0]], 'journal')
        tx, _, _ = app.build_txns(t, 'j')
        self.assertEqual([(x.direction, x.cents) for x in tx], [('支', 10000)])

    def test_ambiguous_j_d_is_not_guessed(self):
        t = table(JHEAD, [[DAY, '1', '', '甲方', 100, '√', '√', 0, 0]], 'journal')
        tx, ignored, _ = app.build_txns(t, 'j')
        self.assertEqual(tx, [])
        self.assertTrue(ignored)

    def test_explicit_bank_direction_overrides_all_positive_amount(self):
        t = table(BHEAD + ['收付标志'], [['本公司', '供应商', DAY, 100, None, '', '付']], 'bank')
        tx, _, _ = app.build_txns(t, 'b')
        self.assertEqual([(x.direction, x.raw_name) for x in tx], [('支', '供应商')])

    def test_own_name_and_counterparty_for_positive_payments(self):
        t = table(BHEAD, [['我公司', '甲方', DAY, 100, None, ''],
                         ['乙方', '我公司', DAY, 200, None, '']], 'bank')
        tx, _, _ = app.build_txns(t, 'b', {'甲方', '乙方'})
        self.assertEqual([(x.direction, x.raw_name) for x in tx], [('支', '甲方'), ('收', '乙方')])

    def test_balance_recovers_directions_without_payer_receiver(self):
        t = table(BHEAD, [['', '', DAY, 100, 1100, ''],
                         ['', '', DAY + timedelta(days=1), 50, 1050, ''],
                         ['', '', DAY + timedelta(days=2), 200, 1250, '']], 'bank')
        tx, ignored, _ = app.build_txns(t, 'b')
        self.assertEqual([(x.row_no, x.direction) for x in tx], [(3, '支'), (4, '收')])
        self.assertIn(('b', 2), ignored)

    def test_invalid_date_is_not_matched_as_zero_days(self):
        j = [txn('j', 2, 10000, day=None)]
        b = [txn('b', 2, 10000)]
        self.assertFalse(match(j, b))

    def test_nonfinite_amounts_are_rejected_without_crash(self):
        for value in ['NaN', 'Infinity', Decimal('NaN'), Decimal('Infinity')]:
            with self.subTest(value=str(value)):
                self.assertIsNone(app.parse_amount(value))

    def test_float_rounding_is_decimal_half_up(self):
        self.assertEqual(app.parse_amount(1.005), 101)

    def test_negative_bank_amount_and_payment_flag_do_not_double_flip(self):
        t = table(BHEAD + ['收付标志'], [['我公司', '甲方', DAY, -100, None, '', '付']], 'bank')
        tx, ignored, _ = app.build_txns(t, 'b', {'甲方'})
        self.assertEqual([(x.direction, x.cents) for x in tx], [('支', 10000)])
        self.assertFalse(ignored)

    def test_two_amount_bank_columns_retain_directional_counterparty(self):
        t = table(['日期', '付款人名称', '收款人名称', '收入金额', '支出金额'],
                  [[DAY, '甲方', '本公司', 100, 0], [DAY, '本公司', '乙方', 0, 200]], 'bank')
        tx, _, _ = app.build_txns(t, 'b')
        self.assertEqual([(x.direction, x.raw_name) for x in tx], [('收', '甲方'), ('支', '乙方')])

    def test_j_d_file_without_blank_debit_credit_columns(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'j.xlsx'
            wb = app.Workbook()
            wb.active.append(JHEAD[:7])
            wb.active.append([DAY, '001', '', '甲方', 100, '√', ''])
            wb.save(path)
            wb.close()
            t = app.prepare_table(str(path), 'journal')
            tx, _, _ = app.build_txns(t, 'j')
            self.assertEqual([(x.direction, x.cents) for x in tx], [('收', 10000)])

    def test_reverse_chronological_balance(self):
        t = table(BHEAD, [['', '', DAY + timedelta(days=2), 200, 1250, ''],
                         ['', '', DAY + timedelta(days=1), 50, 1050, ''],
                         ['', '', DAY, 100, 1100, '']], 'bank')
        tx, _, _ = app.build_txns(t, 'b')
        self.assertEqual([(x.row_no, x.direction) for x in tx], [(2, '收'), (3, '支')])

    def test_single_bank_negative_amount_with_payment_flag(self):
        t = table(['日期', '对方户名', '交易金额', '收付标志'], [[DAY, '甲方', -100, '付']], 'bank')
        tx, ignored, _ = app.build_txns(t, 'b')
        self.assertEqual([(x.direction, x.cents) for x in tx], [('支', 10000)])
        self.assertFalse(ignored)

    def test_bank_cash_flag_pair_keeps_cash_direction(self):
        t = table(['日期', '交易金额', '收', '付', '对方户名'],
                  [[DAY, 100, '√', '', '甲方'], [DAY, 200, '', '√', '乙方']], 'bank')
        tx, _, _ = app.build_txns(t, 'b')
        self.assertEqual([(x.direction, x.cents) for x in tx], [('收', 10000), ('支', 20000)])


class MatchingTests(unittest.TestCase):
    def test_exact_pairs(self):
        j, b = [txn('j', 2, 12345)], [txn('b', 3, 12345)]
        self.assertEqual(len(match(j, b)), 1)

    def test_opposite_direction_is_never_used(self):
        self.assertFalse(match([txn('j', 2, 12345)], [txn('b', 3, 12345, direction='支')]))

    def test_repeated_amount_preserves_strong_reference_pairing(self):
        j = [txn('j', 2, 10000, summary='订单ABCD1001'), txn('j', 3, 10000, summary='订单ABCD1002')]
        b = [txn('b', 2, 10000, summary='ABCD1001'), txn('b', 3, 10000, summary='ABCD1002')]
        match(j, b)
        self.assertEqual([x.match_id for x in j], [x.match_id for x in b])

    def test_weak_candidate_cannot_displace_strong_reference(self):
        j = [txn('j', 2, 10000, summary='订单ABCD1001'), txn('j', 3, 10000)]
        b = [txn('b', 2, 10000, summary='ABCD1001'), txn('b', 3, 10000)]
        match(j, b)
        self.assertEqual(j[0].match_id, b[0].match_id)

    def test_fee_candidate_is_partial_and_separate_from_confirmed_rate(self):
        j, b = [txn('j', 2, 100000)], [txn('b', 2, 99900)]
        groups = match(j, b)
        jt = app.Table('', '', '', rows=[(2, [])])
        bt = app.Table('', '', '', rows=[(2, [])])
        res = app.Result(jt, bt, j, b, groups, {}, [], app.Options(), 0, '', '')
        self.assertEqual(app.build_row_summary(res, 'j')[2][0], '部分匹配')
        stats = app.compute_stats(res)
        self.assertEqual(stats['j_confirmed'], 0)
        self.assertEqual(stats['j_review'], 1)

    def test_cancellation_stops_matching(self):
        import threading
        cancel = threading.Event()
        cancel.set()
        with self.assertRaises(app.UserError):
            app.match_all([txn('j', 2, 10000)], [txn('b', 2, 10000)], app.Options(), cancel=cancel)

    def test_dense_indistinguishable_duplicates_are_marked_for_review(self):
        j = [txn('j', i + 2, 10000) for i in range(600)]
        b = [txn('b', i + 2, 10000) for i in range(600)]
        groups = match(j, b)
        self.assertEqual(len(groups), 600)
        self.assertTrue(all(t.match_type == '重复等额' and t.note for t in j + b))

    def test_assignment_maximizes_cardinality_before_quality(self):
        j = [txn('j', 2, 10000, day=0), txn('j', 3, 10000, day=1)]
        b = [txn('b', 2, 10000, day=-1), txn('b', 3, 10000, day=0)]
        match(j, b, date_window=1)
        self.assertTrue(all(x.used for x in j + b))
        self.assertEqual(j[0].match_id, b[0].match_id)

    def test_grouping_precedes_fee_matching(self):
        j = [txn('j', 2, 10000)]
        b = [txn('b', 2, 9900), txn('b', 3, 100)]
        groups = match(j, b)
        self.assertEqual([len(g) for g in groups.values()], [3])
        self.assertTrue(all(x.used for x in b))

    def test_many_to_one(self):
        j = [txn('j', 2, 4000), txn('j', 3, 6000)]
        b = [txn('b', 2, 10000)]
        self.assertEqual([len(g) for g in match(j, b).values()], [3])

    def test_many_to_many(self):
        j = [txn('j', 2, 4000), txn('j', 3, 6000)]
        b = [txn('b', 2, 3000), txn('b', 3, 7000)]
        groups = match(j, b)
        self.assertEqual([len(g) for g in groups.values()], [4])

    def test_ambiguous_subset_is_not_first_found(self):
        j = [txn('j', 2, 10000)]
        b = [txn('b', i + 2, a) for i, a in enumerate([6000, 4000, 7000, 3000])]
        self.assertFalse(match(j, b, fee_cap=0))
        self.assertTrue(j[0].note)

    def test_cross_day_unique_exact_match(self):
        j = [txn('j', 2, 10000)]
        b = [txn('b', 2, 10000, day=5)]
        self.assertEqual(len(match(j, b)), 1)
        self.assertIn('跨日', j[0].match_type)

    def test_outside_extended_window_is_not_matched(self):
        self.assertFalse(match([txn('j', 2, 10000)], [txn('b', 2, 10000, day=60)]))

    def test_missing_name_with_multiple_candidates_stays_unmatched(self):
        j = [txn('j', 2, 10000, name='')]
        b = [txn('b', 2, 10000, name='张三'), txn('b', 3, 10000, name='李四')]
        self.assertFalse(match(j, b, fee_cap=0))

    def test_unrelated_names_do_not_become_matchable_globally(self):
        j = [txn('j', i + 2, 10000 + i, name='甲方') for i in range(25)]
        b = [txn('b', i + 2, 10000 + i, name='乙方') for i in range(25)]
        opts, _ = app.auto_tune(j, b, app.Options(), [])
        self.assertTrue(opts.name_strict)
        self.assertFalse(app.match_all(j, b, opts))

    def test_short_person_name_is_not_substring_match(self):
        self.assertFalse(match([txn('j', 2, 10000, name='张三')],
                               [txn('b', 2, 10000, name='张三丰')]))

    def test_no_txn_is_reused_and_all_exact_groups_balance(self):
        j = [txn('j', i + 2, 10000 + i) for i in range(50)]
        b = [txn('b', i + 2, 10000 + i) for i in reversed(range(50))]
        groups = match(j, b)
        members = [x for g in groups.values() for x in g]
        self.assertEqual(len(set(members)), 100)
        for g in groups.values():
            self.assertEqual(sum(x.cents for x in g if x.src == 'j'), sum(x.cents for x in g if x.src == 'b'))

    def test_many_to_one_row_difference_uses_group_total(self):
        j = [txn('j', 2, 4000), txn('j', 3, 6000)]
        b = [txn('b', 2, 10000)]
        groups = match(j, b)
        res = app.Result(None, None, j, b, groups, {}, [], app.Options(), 0, '', '')
        self.assertEqual([s[-1] for s in app.build_row_summary(res, 'j').values()], [0, 0])

    def test_existing_ambiguity_note_survives_explanation(self):
        j, b = [txn('j', 2, 10000)], [txn('b', 2, 10000, name='乙方')]
        j[0].note = '多个候选，无法唯一确认'
        app.explain_unmatched(j, b, app.Options())
        self.assertEqual(j[0].note, '多个候选，无法唯一确认')


class EndToEndTests(unittest.TestCase):
    def test_screenshot_headers_to_export(self):
        with tempfile.TemporaryDirectory() as folder:
            paths = [Path(folder) / f'{name}.xlsx' for name in ['journal', 'bank', 'result']]
            for path, head, rows in [
                (paths[0], JHEAD, [[DAY, '记001', '订单ABCD1001', '甲方', 100, '√', '', 0, 0],
                                  [DAY, '记002', '订单ABCD1002', '乙方', 200, '', '√', 0, 0]]),
                (paths[1], BHEAD, [['甲方', '我公司', DAY, 100, 1100, 'ABCD1001'],
                                  ['我公司', '乙方', DAY, 200, 900, 'ABCD1002']])]:
                wb = app.Workbook()
                wb.active.append(head)
                for row in rows:
                    wb.active.append(row)
                wb.save(path)
                wb.close()
            res = app.reconcile(str(paths[0]), str(paths[1]))
            self.assertEqual(app.compute_stats(res)['j_matched'], 2)
            self.assertEqual(app.compute_stats(res)['b_matched'], 2)
            app.export_result(res, str(paths[2]))
            wb = app.load_workbook(paths[2], data_only=True)
            self.assertIn('左右并列核对', wb.sheetnames)
            self.assertIn('对账汇总', wb.sheetnames)
            wb.close()


if __name__ == '__main__':
    unittest.main(verbosity=2)
