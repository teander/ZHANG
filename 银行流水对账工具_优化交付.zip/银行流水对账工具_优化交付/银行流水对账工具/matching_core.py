"""金额按分计算的离线匹配引擎；不依赖 GUI 或第三方优化库。"""
from collections import defaultdict, deque
from datetime import timedelta
import heapq
import re
import time


class _SearchLimit(Exception):
    pass


def tokens(txn):
    return frozenset(re.findall(r'[A-Za-z0-9]{4,}', (txn.summary or '').upper()))


def day_gap(a, b):
    return abs((a.d - b.d).days) if a.d is not None and b.d is not None else 10**9


def _optimal_edges(edges, check):
    """每个连通分量求最大流最小费用：先最多笔数，再最优证据总分。"""
    adjacent = defaultdict(list)
    for edge in edges:
        a, b, _sim, _gap, _cost = edge
        adjacent[a].append(edge)
        adjacent[b].append(edge)
    seen = set()
    answer = []
    for seed in adjacent:
        if seed in seen:
            continue
        component, queue = set(), deque([seed])
        while queue:
            node = queue.popleft()
            if node in seen:
                continue
            seen.add(node)
            component.add(node)
            for a, b, *_ in adjacent[node]:
                if a not in seen:
                    queue.append(a)
                if b not in seen:
                    queue.append(b)
        ce = [e for a in component if a.src == 'j' for e in adjacent[a]]
        js = sorted({e[0] for e in ce}, key=lambda x: (x.d, x.row_no))
        bs = sorted({e[1] for e in ce}, key=lambda x: (x.d, x.row_no))
        nodes = js + bs
        ids = {t: i + 1 for i, t in enumerate(nodes)}
        sink = len(nodes) + 1
        graph = [[] for _ in range(sink + 1)]

        def add(u, v, cost):
            f = [v, len(graph[v]), 1, cost]
            r = [u, len(graph[u]), 0, -cost]
            graph[u].append(f)
            graph[v].append(r)
            return f

        for a in js:
            add(0, ids[a], 0)
        for b in bs:
            add(ids[b], sink, 0)
        handles = [(e, add(ids[e[0]], ids[e[1]], e[4])) for e in ce]
        potential = [0] * len(graph)
        while True:
            check()
            distance = [float('inf')] * len(graph)
            parent = [None] * len(graph)
            distance[0] = 0
            heap = [(0, 0)]
            scans = 0
            while heap:
                dist, u = heapq.heappop(heap)
                if dist != distance[u]:
                    continue
                scans += 1
                if scans % 256 == 0:
                    check()
                for i, (v, _rev, capacity, cost) in enumerate(graph[u]):
                    if capacity:
                        nd = dist + cost + potential[u] - potential[v]
                        if nd < distance[v]:
                            distance[v], parent[v] = nd, (u, i)
                            heapq.heappush(heap, (nd, v))
            if parent[sink] is None:
                break
            for i, d in enumerate(distance):
                if d < float('inf'):
                    potential[i] += d
            v = sink
            while v:
                u, i = parent[v]
                edge = graph[u][i]
                edge[2] -= 1
                graph[v][edge[1]][2] += 1
                v = u
        answer.extend(e[:4] for e, handle in handles if handle[2] == 0)
    return answer


def assign_pairs(js, bs, opts, similarity, tol=0, window=None, unique=False, check=lambda: None):
    window = opts.date_window if window is None else window
    deadline = time.monotonic() + getattr(opts, 'pair_seconds', 10.0)

    def bounded_check():
        check()
        if time.monotonic() > deadline:
            raise _SearchLimit()

    def mark_limit():
        for t in js + bs:
            if not t.used:
                t.note = '同额候选过密或最优分配达到计算上限，请缩小日期范围或手工核对'

    by_day = defaultdict(list)
    for b in bs:
        if not b.used and b.d is not None:
            by_day[(b.direction, b.d)].append(b)
    edges, jd, bd = [], defaultdict(int), defaultdict(int)
    examined = 0
    for n, a in enumerate(js):
        if n % 100 == 0:
            check()
            if time.monotonic() > deadline:
                mark_limit()
                return []
        if a.used or a.d is None:
            continue
        for offset in range(-window, window + 1):
            for b in by_day.get((a.direction, a.d + timedelta(days=offset)), ()):
                examined += 1
                if examined % 512 == 0:
                    check()
                    if time.monotonic() > deadline:
                        mark_limit()
                        return []
                gap = abs(a.cents - b.cents)
                if (not tol and gap) or (tol and not 0 < gap <= tol):
                    continue
                sim = similarity(a.name, b.name) if a.name and b.name else 0.55
                reference = bool(tokens(a) & tokens(b))
                named = bool(a.name and b.name)
                if named and sim < opts.name_threshold:
                    continue
                if unique and (not named or sim < max(0.9, opts.name_threshold)):
                    continue
                delta = day_gap(a, b)
                cost = 100000 - round(sim * 10000) - 5000 * reference + delta * 80 + min(gap, 10000)
                edges.append((a, b, sim, delta, cost))
                if len(edges) > getattr(opts, 'pair_edge_cap', 60000):
                    mark_limit()
                    return []
                jd[a] += 1
                bd[b] += 1
    safe = []
    for edge in edges:
        a, b, _sim, _delta, _cost = edge
        weak = not a.name or not b.name
        if (unique or weak) and (jd[a] != 1 or bd[b] != 1):
            for t in (a, b):
                if not t.note:
                    t.note = '同金额存在多个候选，证据不足以唯一确认，请手工核对'
            continue
        safe.append(edge)
    try:
        return _optimal_edges(safe, bounded_check)
    except _SearchLimit:
        mark_limit()
        return []


def unique_subset(pool, target, limit, budget, seconds, check):
    """枚举到第二个解即停止；超预算时不把尚未证实唯一的解当成匹配。"""
    pool = sorted(pool, key=lambda t: (-t.cents, t.row_no))
    if len(pool) < 2 or limit < 2 or sum(t.cents for t in pool) < target:
        return None, ''
    if len(pool) <= limit and sum(t.cents for t in pool) == target:
        return pool, ''
    suffix = [0] * (len(pool) + 1)
    for i in range(len(pool) - 1, -1, -1):
        suffix[i] = suffix[i + 1] + pool[i].cents
    solutions, chosen, exhausted = [], [], False
    deadline = time.monotonic() + seconds
    remaining_budget = budget

    def visit(start, remaining):
        nonlocal exhausted, remaining_budget
        if remaining == 0:
            if len(chosen) >= 2:
                solutions.append(list(chosen))
            return
        if len(chosen) >= limit or start >= len(pool) or suffix[start] < remaining:
            return
        if sum(t.cents for t in pool[start:start + limit - len(chosen)]) < remaining:
            return
        for i in range(start, len(pool)):
            remaining_budget -= 1
            if remaining_budget % 256 == 0:
                check()
            if remaining_budget <= 0 or time.monotonic() > deadline:
                exhausted = True
                return
            if pool[i].cents > remaining:
                continue
            chosen.append(pool[i])
            visit(i + 1, remaining - pool[i].cents)
            chosen.pop()
            if exhausted or len(solutions) >= 2:
                return

    visit(0, target)
    if len(solutions) >= 2:
        return None, '金额加总存在多个组合，请结合凭证或单号手工核对'
    if exhausted:
        return None, '合并搜索达到时间或节点上限，尚未证明组合唯一，请手工核对'
    return (solutions[0], '') if solutions else (None, '')


def match_transactions(js, bs, opts, similarity, report=None, cancel=None, error_type=ValueError):
    groups = {}

    def check():
        if cancel is not None and cancel.is_set():
            raise error_type('已取消')

    def emit(message, percent):
        check()
        if report:
            report(message, percent)

    def link(members, kind, note=''):
        if any(t.used for t in members):
            return
        gid = len(groups) + 1
        groups[gid] = members
        for t in members:
            t.used, t.match_id, t.match_type = True, gid, kind
            t.note = note

    def commit(pairs, kind=None):
        for a, b, sim, _delta in pairs:
            typ = kind or ('精确' if sim >= 0.999 else '名称匹配')
            if not a.name or not b.name:
                typ = '金额匹配'
            note = '至少一侧缺少户名，已按金额、日期双向唯一配对，请复核' if typ == '金额匹配' else ''
            if kind in ('容差', '部分匹配'):
                note = '实际金额差额 {0:+.2f} 元，请复核手续费或入账差额'.format((a.cents - b.cents) / 100)
            if kind == '跨日匹配':
                note = '相同金额及高相似户名在扩展日期窗口内双向唯一，日期相差 {0} 天，请复核'.format(_delta)
            link([a, b], typ, note)

    emit('一对一精确匹配（最大笔数及最优证据分配）…', 34)
    jb, bb = defaultdict(list), defaultdict(list)
    for t in js:
        jb[(t.direction, t.cents)].append(t)
    for t in bs:
        bb[(t.direction, t.cents)].append(t)
    for key in sorted(jb.keys() & bb.keys()):
        check()
        jl, bl = jb[key], bb[key]
        # 所有可区分信息在各侧均相同时，无需构造 n*n 完全图；按行次关联并要求复核。
        if len(jl) > 1 and len(bl) > 1:
            shapes_j = {(t.d, t.name, t.summary) for t in jl}
            shapes_b = {(t.d, t.name, t.summary) for t in bl}
            if len(shapes_j) == len(shapes_b) == 1:
                jd, jn, _ = next(iter(shapes_j))
                bd, bn, _ = next(iter(shapes_b))
                if jd is not None and jd == bd and jn and jn == bn:
                    for a, b in zip(sorted(jl, key=lambda t: t.row_no), sorted(bl, key=lambda t: t.row_no)):
                        link([a, b], '重复等额', '同日同户名同金额，侧内摘要无法区分；按行次关联，逐笔凭证需复核')
                    continue
        commit(assign_pairs(jb[key], bb[key], opts, similarity, check=check))

    emit('精确合并匹配（一对多 / 多对一 / 多对多）…', 48)
    span = max(opts.date_window, opts.group_window)
    deadline = time.monotonic() + opts.group_seconds
    day_index = {}
    for src, txns in (('j', js), ('b', bs)):
        index = defaultdict(list)
        for t in txns:
            if t.d is not None:
                index[(t.direction, t.d)].append(t)
        day_index[src] = index
    for _round in range(3):
        before = len(groups)
        for anchors, other_src in ((js, 'b'), (bs, 'j')):
            proposals = []
            for a in anchors:
                check()
                if a.used or a.d is None or not a.name:
                    continue
                if time.monotonic() > deadline:
                    a.note = a.note or '合并匹配达到总时间上限，请手工核对'
                    continue
                pool = []
                for offset in range(-span, span + 1):
                    for b in day_index[other_src].get((a.direction, a.d + timedelta(days=offset)), ()):
                        if (not b.used and b.name and 0 < b.cents < a.cents
                                and similarity(a.name, b.name) >= opts.name_threshold):
                            pool.append(b)
                if len(pool) > opts.pool_cap:
                    a.note = '合并候选超过上限，请缩小日期范围或手工核对'
                    continue
                if len(pool) >= 2:
                    proposals.append((len(pool), a, pool))
            proposals.sort(key=lambda x: (x[0], x[1].d, x[1].row_no))
            for _size, a, pool in proposals:
                check()
                if a.used:
                    continue
                if time.monotonic() > deadline:
                    a.note = a.note or '合并匹配达到总时间上限，请手工核对'
                    continue
                pool = [b for b in pool if not b.used]
                referenced = [b for b in pool if tokens(a) & tokens(b)]
                # 同单号优先；没有共同单号时要求整个日期窗口内组合唯一。
                rounds = [referenced, pool] if len(referenced) >= 2 else [pool]
                for candidates in rounds:
                    picked, reason = unique_subset(candidates, a.cents, opts.group_limit - 1,
                                                   opts.group_budget, min(0.25, max(0, deadline - time.monotonic())), check)
                    if picked:
                        link([a] + picked, '组匹配', '同方向、同户名，金额精确加总一致')
                        break
                    if reason:
                        a.note = reason
                        for b in candidates:
                            b.note = b.note or reason
        if len(groups) == before:
            break

    # 多对多只确认一个户名、方向、紧凑日期段内的完整等额组，不声称逐笔对应。
    buckets = defaultdict(lambda: ([], []))
    for side, txns in enumerate((js, bs)):
        for t in txns:
            if not t.used and t.d is not None and t.name:
                buckets[(t.direction, t.name)][side].append(t)
    for jl, bl in buckets.values():
        check()
        combined = sorted(jl + bl, key=lambda t: (t.d, t.row_no))
        pos = 0
        while pos < len(combined):
            end = pos + 1
            while end < len(combined) and (combined[end].d - combined[pos].d).days <= span:
                end += 1
            segment = combined[pos:end]
            pos = end
            left = [t for t in segment if t.src == 'j']
            right = [t for t in segment if t.src == 'b']
            if (2 <= len(left) and 2 <= len(right) and len(segment) <= opts.group_limit
                    and sum(t.cents for t in left) == sum(t.cents for t in right)):
                link(segment, '多对多汇总', '同户名、同方向、日期段内整组金额一致；组内逐笔对应需复核')

    emit('跨日精确匹配（高相似户名且双向唯一）…', 60)
    extended = max(opts.date_window, getattr(opts, 'extended_window', 7))
    for key in sorted(jb.keys() & bb.keys()):
        check()
        commit(assign_pairs(jb[key], bb[key], opts, similarity, window=extended, unique=True, check=check), '跨日匹配')

    tol = round(opts.amount_tol * 100)
    if tol > 0:
        emit('金额容差匹配（精确合并完成后）…', 63)
        commit(assign_pairs(js, bs, opts, similarity, tol=tol, check=check), '容差')

    if opts.fee_cap > 0:
        emit('小额差额候选（需复核）…', 66)
        # 金额不同的配对只接受强户名证据，以及双方各自唯一的最小差额。
        ranked = defaultdict(list)
        by_day = defaultdict(list)
        for b in bs:
            if not b.used and b.d is not None and b.name:
                by_day[(b.direction, b.d)].append(b)
        fee_span = max(opts.fee_days, min(opts.date_window, 7))
        for a in js:
            check()
            if a.used or a.d is None or not a.name:
                continue
            for offset in range(-fee_span, fee_span + 1):
                for b in by_day.get((a.direction, a.d + timedelta(days=offset)), ()):
                    gap = abs(a.cents - b.cents)
                    cap = min(opts.fee_cap, max(1, int(min(a.cents, b.cents) * opts.fee_ratio)))
                    if not 0 < gap <= cap:
                        continue
                    sim = similarity(a.name, b.name)
                    if sim < max(0.9, opts.name_threshold):
                        continue
                    edge = (a, b, sim, abs(offset))
                    score = (gap, abs(offset), -sim)
                    ranked[a].append((score, edge))
                    ranked[b].append((score, edge))
        best = {}
        for t, candidates in ranked.items():
            candidates.sort(key=lambda x: x[0])
            if len(candidates) == 1 or candidates[0][0] < candidates[1][0]:
                best[t] = candidates[0][1]
        for a in js:
            edge = best.get(a)
            if edge and best.get(edge[1]) == edge and not a.used and not edge[1].used:
                commit([edge], '部分匹配')
    check()
    return groups
