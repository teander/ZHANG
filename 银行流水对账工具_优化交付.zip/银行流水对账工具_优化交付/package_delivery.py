"""打包可运行目录、修改说明和验证资料；不打包缓存与运行日志。"""
from pathlib import Path
import hashlib
import zipfile

root = Path(__file__).resolve().parent
destination = root.parent / '银行流水对账工具_优化版_v2.3.0.zip'
with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if not path.is_file() or any(part in ('__pycache__', 'logs') for part in relative.parts):
            continue
        if path.suffix.lower() in ('.pyc', '.pyo'):
            continue
        archive.write(path, Path(root.name) / relative)
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    names = archive.namelist()
    for required in ['银行流水对账工具/银行流水对账工具.py', '银行流水对账工具/matching_core.py',
                     '银行流水对账工具/双击运行对账工具.bat', '银行流水对账工具/pylibs/openpyxl/__init__.py',
                     '修改说明.md', '验证资料/测试结果.txt', '验证资料/模拟样例_对账结果.xlsx']:
        assert f'{root.name}/{required}' in names, required
checksum = hashlib.sha256(destination.read_bytes()).hexdigest()
destination.with_suffix('.zip.sha256').write_text(checksum + '  ' + destination.name + '\n', encoding='utf-8')
print(destination)
print('Archive files:', len(names))
print('Bytes:', destination.stat().st_size)
print('SHA256:', checksum)
