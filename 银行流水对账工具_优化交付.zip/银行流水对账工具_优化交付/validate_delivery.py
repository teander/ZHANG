"""重建模拟样例、原版对比和验证报告，所有数据均为虚构。"""
from pathlib import Path
import difflib
import importlib.util
import json
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parent
APP = ROOT / '银行流水对账工具'
sys.path.insert(0, str(APP))
import test_reconciliation as tests

app = tests.app
OUT = ROOT / '验证资料'
OUT.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location('original_recon', ROOT / '原始源码备份' / '银行流水对账工具.py')
old = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = old
spec.loader.exec_module(old)

report = {'说明': '仅模拟数据及回归测试；不代表用户真实账目匹配率。', 'version': app.VERSION}
with (OUT / '测试结果.txt').open('w', encoding='utf-8') as stream:
    suite = unittest.defaultTestLoader.discover(str(APP), pattern='test_*.py')
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
report['tests'] = {'run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors)}
assert result.wasSuccessful()


def make_txns(module, spec, src):
    return [module.Txn(src, i + 2, direction, cents, tests.DAY + tests.timedelta(days=days), name, name, summary)
            for i, (cents, name, days, summary, direction) in enumerate(spec)]


def case(name, j_spec, b_spec):
    comparison = {'场景': name}
    for label, module in [('原版', old), ('新版', app)]:
        js, bs = make_txns(module, j_spec, 'j'), make_txns(module, b_spec, 'b')
        groups = module.match_all(js, bs, module.Options())
        balanced = [g for g in groups.values() if sum(t.cents for t in g if t.src == 'j') == sum(t.cents for t in g if t.src == 'b')]
        comparison[label] = {'日记账关联': sum(t.used for t in js), '流水关联': sum(t.used for t in bs),
                             '精确金额相等的组': len(balanced), '总组数': len(groups)}
    return comparison


N = '模拟甲方有限公司'
report['cases'] = [
    case('跨5天唯一同户名同金额', [(10000, N, 0, '', '收')], [(10000, N, 5, '', '收')]),
    case('100元精确拆为99元及1元，不能先认手续费', [(10000, N, 0, '', '收')],
         [(9900, N, 0, '', '收'), (100, N, 0, '', '收')]),
    case('多对多：40+60元对应30+70元', [(4000, N, 0, '', '收'), (6000, N, 0, '', '收')],
         [(3000, N, 0, '', '收'), (7000, N, 0, '', '收')]),
]
report['performance'] = []
for title, count, dense in [('不同金额', 3000, False), ('全部同日同额且无可区分摘要', 5000, True)]:
    js = [tests.txn('j', i + 2, 10000 if dense else 10000 + i) for i in range(count)]
    bs = [tests.txn('b', i + 2, 10000 if dense else 10000 + i) for i in range(count)]
    started = time.perf_counter()
    groups = app.match_all(js, bs, app.Options())
    report['performance'].append({'场景': title, '每侧笔数': count, '组数': len(groups),
                                  '秒': round(time.perf_counter() - started, 4),
                                  '逐笔需复核': sum(t.match_type == '重复等额' for t in js)})
    assert len(groups) == count

# 样例涵盖截图字段、收支、单笔、一对多、多对一、多对多及延迟5天入账。
j_spec = [(100, '模拟甲方', 0, '收', 'ABCD1001'), (200, '模拟乙方', 0, '支', 'ABCD1002'),
          (300, '模拟丙方', 0, '收', 'ABCD1003'), (150, '模拟丁方', 0, '支', ''),
          (250, '模拟丁方', 0, '支', ''), (500, '模拟戊方', 0, '收', 'ABCD1005'),
          (300, '模拟己方', 0, '收', ''), (400, '模拟己方', 0, '收', '')]
b_spec = [(100, '模拟甲方', 0, '收', 'ABCD1001'), (200, '模拟乙方', 0, '支', 'ABCD1002'),
          (100, '模拟丙方', 0, '收', 'ABCD1003'), (200, '模拟丙方', 0, '收', 'ABCD1003'),
          (400, '模拟丁方', 0, '支', ''), (500, '模拟戊方', 5, '收', 'ABCD1005'),
          (200, '模拟己方', 0, '收', ''), (500, '模拟己方', 0, '收', '')]
for name, head, rows in [('模拟样例_日记账.xlsx', tests.JHEAD, j_spec), ('模拟样例_银行流水.xlsx', tests.BHEAD, b_spec)]:
    wb = app.Workbook()
    ws = wb.active
    ws.append(head)
    balance = 10000
    for i, (amount, party, days, direction, summary) in enumerate(rows):
        day = tests.DAY + tests.timedelta(days=days)
        if '日记账' in name:
            row = [day, f'记{i + 1:03d}', summary, party, amount,
                   '√' if direction == '收' else '', '√' if direction == '支' else '', 0, 0]
        else:
            balance += amount if direction == '收' else -amount
            row = [party if direction == '收' else '模拟本公司',
                   '模拟本公司' if direction == '收' else party, day, amount, balance, summary]
        ws.append(row)
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions
    for col in range(1, len(head) + 1):
        ws.column_dimensions[app.get_column_letter(col)].width = 20
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            if isinstance(cell.value, tests.date):
                cell.number_format = 'yyyy-mm-dd'
    wb.save(OUT / name)
    wb.close()

res = app.reconcile(str(OUT / '模拟样例_日记账.xlsx'), str(OUT / '模拟样例_银行流水.xlsx'))
app.export_result(res, str(OUT / '模拟样例_对账结果.xlsx'))
stats = app.compute_stats(res)
report['sample'] = {k: stats[k] for k in ['j_txns', 'b_txns', 'j_matched', 'b_matched', 'j_confirmed', 'j_review']}
assert stats['j_matched'] == stats['j_txns'] == 8
assert stats['b_matched'] == stats['b_txns'] == 8
assert all(sum(t.cents for t in g if t.src == 'j') == sum(t.cents for t in g if t.src == 'b') for g in res.groups.values())
wb = app.load_workbook(OUT / '模拟样例_对账结果.xlsx', data_only=True)
report['sample']['导出工作表'] = wb.sheetnames
wb.close()

before = (ROOT / '原始源码备份' / '银行流水对账工具.py').read_text(encoding='utf-8-sig').splitlines(True)
after = (APP / '银行流水对账工具.py').read_text(encoding='utf-8').splitlines(True)
(OUT / '主程序修改.diff').write_text(''.join(difflib.unified_diff(before, after, fromfile='v2.2.2/银行流水对账工具.py', tofile='v2.3.0/银行流水对账工具.py')), encoding='utf-8')
(OUT / '验证报告.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
